cd C:\\Users\\ggotm\\Desktop\\trading; python server.py --ticker CCM6 # дашборд + бот (песочница)
python server.py --ticker GZM6          # дашборд + GAZR-бот
python server.py --ticker CRM6          # дашборд + CNY-бот
python server.py --ticker GDM6          # дашборд + GOLD-бот

python backtest.py --ticker CCM6 --days 14 --interval 1   # бэктест 14д
python backtest.py --ticker GZM6 --days 14 --interval 1

python bot.py --ticker GZM6             # только бот, без дашборда



запуск тестов

python -m pytest tests -v



cd C:\\Users\\ggotm\\Desktop\\trading; python run.py



=== ИНДИКАТОРЫ СТРАТЕГИИ ===

EMA (9/21) — экспоненциальная скользящая средняя. Fast (9) = краткосрочный тренд, Slow (21) = долгосрочный. Trend = EF > ES (LONG) / EF < ES (SHORT). Margin 0.005% — anti-flicker.

RSI (14) — индекс относительной силы (0–100). Oversold <30 → сигнал LONG, Overbought >70 → SHORT. Фильтр RSI\_OVERBOUGHT\_FILTER=55 блокирует LONG при RSI >55.

ADX — Average Directional Index, сила тренда (0–100). ≥22 = тренд есть, <22 = флэт. Бот не входит без ADX. Требует минимум 29 свечей для первого расчёта.

BB — полосы Боллинджера (20,2). Band-edge mode: LONG при цене у нижней полосы (±0.25%), SHORT у верхней. BB\_TOLERANCE=0 = within-bands (блокирует вход за границей).

Momentum — изменение цены за N свечей (%). ≥0.005% для входа. Направление не важно (abs(momentum)) — feature не bug: ловит SHORT при откатах вверх в downtrend.

Volume — объём последней свечи vs средний за 20. ≥1.2× от среднего, минимум 10 контрактов.

Percentile Filter — 100 = выключен. 95 = блокирует LONG в top 5% диапазона за 5 дней. Чем ниже, тем консервативнее.

=== РИСК-МЕНЕДЖМЕНТ ===

SL (1.2%) — Stop Loss, принудительное закрытие при убытке.
TP (1.5%) — Take Profit, фиксация прибыли.
Trailing — активация при +0.8% от entry, дистанция 0.4% от пика. Защищает набранную прибыль.
Circuit Breaker — 2 убытка подряд (MAX\_CONSECUTIVE\_LOSSES) → блокировка входа на 3600с (CIRCUIT\_BREAKER\_COOLDOWN).
Cooldown — таймаут 600с (MIN\_COOLDOWN\_SEC) после любого выхода.
Signal Streak — N сигналов одного направления подряд перед входом (MIN\_SIGNAL\_STREAK, глобально=2, GZM6=3).
Spread Filter — get\_order\_book перед входом. Если спред > MAX\_SPREAD\_PCT — пропуск входа. 0 = выключен.
DD Max — максимальная просадка капитала (%) от исторического пика.
DD 95% — 95-й перцентиль просадки по Monte Carlo, худший сценарий с 95% вероятностью.
LOT — 0 = авто (через LEVERAGE\_FACTOR), >0 = фиксированное количество контрактов.
LEVERAGE\_FACTOR — доля депозита на 1 контракт (1.0 = 100%). При 0.5, LOT=1 на GZM6.

=== МЕТРИКИ БЭКТЕСТА ===

Win Rate (WR) — % прибыльных сделок (75% на GZM6 60d).
Profit Factor (PF) — сумма прибыли / сумма убытков. >1 = профит, >2 = отлично.
Sharpe Ratio — доходность / волатильность. >3 = отлично, >4 = выдающийся.
Monte Carlo — 2000 симуляций перемешанных сделок. %profit = вероятность закончить в плюсе (\~90%).
Notional — цена × contract\_multiplier, стоимость 1 контракта.

=== АРХИТЕКТУРА ===

Sandbox — торговля на виртуальные деньги (SANDBOX=True, client.sandbox.\* API).
Real — реальный счёт (--mode real, TINKOFF\_TOKEN в .env).
Resume — восстановление позиции при перезапуске из портфеля API.
Margin check — funds\_sufficiency\_level > 1.0 перед входом. В sandbox guarantee\_for\_futures = 0 (баг API, блокировка не отображается).
Server — FastAPI на порту 5000, дашборд (TradingView) + SSE-события + REST-управление.
Briefing — генерация аналитического брифинга (RSI, MACD, BB) раз в день в briefings/.
Console log — дубль print()/stderr в терминал + logs/console\_YYYYMMDD.log.

