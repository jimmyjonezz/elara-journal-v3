#!/data/data/com.termux/files/usr/bin/bash
# termux_start.sh — запуск торгового бота на Android (Termux)
# Использование: bash termux_start.sh <command> [--ticker TICKER]

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

# Парсинг аргументов
TICKER="NAM6"
ARGS=()
while [[ $# -gt 0 ]]; do
    case "$1" in
        --ticker) TICKER="$2"; shift 2 ;;
        --ticker=*) TICKER="${1#*=}"; shift ;;
        *) ARGS+=("$1"); shift ;;
    esac
done
set -- "${ARGS[@]}"

load_env() {
    if [ -f .env ]; then
        python3 -c "
from dotenv import load_dotenv
load_dotenv('$DIR/.env')
import os
for k, v in sorted(os.environ.items()):
    if k.startswith('TINKOFF_') or k in ('API_TOKEN','ACCOUNT_ID','BOT_TICKER'):
        print(f'export {k}={repr(v)}')
" > /tmp/trading_env.sh 2>/dev/null && source /tmp/trading_env.sh
    fi
}

case "${1:-server}" in
    server)
        echo "=== Bot: FastAPI + Bot (тикер $TICKER) ==="
        echo "[1/4] Wake lock..."
        termux-wake-lock trading 2>/dev/null || echo "  (termux-api not installed — wake-lock skipped)"
        trap 'termux-wake-unlock trading 2>/dev/null || true; echo "Wake lock released"' EXIT

        echo "[2/4] Loading .env..."
        load_env

        echo "[3/4] Freeing port 5000..."
        fuser -k 5000/tcp 2>/dev/null || true
        sleep 1

        echo "[4/4] Starting server..."
        python server.py --ticker "$TICKER"
        ;;
    bot)
        echo "=== Bot only (no dashboard, тикер $TICKER) ==="
        echo "[1/3] Wake lock..."
        termux-wake-lock trading 2>/dev/null || echo "  (termux-api not installed — wake-lock skipped)"
        trap 'termux-wake-unlock trading 2>/dev/null || true; echo "Wake lock released"' EXIT

        echo "[2/3] Loading .env..."
        load_env

        echo "[3/3] Starting bot..."
        python bot.py --ticker "$TICKER"
        ;;
    tmux)
        session="trading"
        echo "=== tmux session '$session' (тикер $TICKER) ==="

        termux-wake-lock trading 2>/dev/null || echo "  (termux-api not installed — wake-lock skipped)"
        trap 'termux-wake-unlock trading 2>/dev/null || true; echo "Wake lock released"' EXIT

        # Kill existing session
        tmux kill-session -t "$session" 2>/dev/null || true

        tmux new-session -d -s "$session" -n bot
        tmux send-keys -t "$session:bot" "cd $DIR && bash termux_start.sh server --ticker $TICKER" Enter

        tmux new-window -t "$session" -n shell
        tmux send-keys -t "$session:shell" "cd $DIR && echo 'Bot running in left pane (Ctrl+B 0). Dashboard: http://localhost:5000/'" Enter

        tmux select-window -t "$session:bot"

        if [ -t 1 ]; then
            echo "Attaching... (Ctrl+B D to detach)"
            tmux attach -t "$session"
        else
            echo "No terminal — running detached. Attach: tmux attach -t $session"
        fi
        ;;
    stop)
        echo "=== Stopping bot ==="
        pkill -f "server.py" 2>/dev/null || true
        pkill -f "bot.py" 2>/dev/null || true
        fuser -k 5000/tcp 2>/dev/null || true
        sleep 1
        echo "Port 5000 freed."
        ;;
    disable-phantom)
        echo "=== Disabling PhantomProcessKiller (Android 12+) ==="
        settings put global settings_enable_monitor_phantom_procs false 2>/dev/null || \
            echo "  Failed (run on device, not in Termux?)"
        echo "Done. Reboot recommended."
        ;;
    install)
        echo "=== Installing Termux dependencies ==="
        pkg update -y
        pkg install -y tmux protobuf rust binutils python termux-api python-pip \
                       grpcio python-aiohttp python-uvicorn

        echo "Python packages..."
        pip install t-tech-investments fastapi uvicorn aiohttp python-dotenv \
            --index-url https://opensource.tbank.ru/api/v4/projects/238/packages/pypi/simple

        echo "Done. Run: bash termux_start.sh tmux --ticker NAM6"
        ;;
    help|*)
        echo "Usage: bash termux_start.sh <command> [--ticker TICKER]"
        echo ""
        echo "Commands:"
        echo "  server            Start FastAPI + bot (default)"
        echo "  bot               Start bot only (no dashboard)"
        echo "  tmux              Start in tmux session (stay alive after closing Termux)"
        echo "  stop              Stop server, free port 5000"
        echo "  disable-phantom   Disable PhantomProcessKiller Android 12+"
        echo "  install           Install Termux/system dependencies"
        echo "  help              Show this help"
        echo ""
        echo "Options:"
        echo "  --ticker TICKER   Instrument ticker (default: NAM6)"
        ;;
esac
