import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["BOT_TICKER"] = "CCM6"

from configbot import VOLUME_MULTIPLIER, VOLUME_ABS_MIN, ADX_MIN, MOMENTUM_MIN, RSI_OVERBOUGHT_FILTER, RSI_OVERSOLD
from bot import analyze_signal


def _ind(**kw):
    defaults = {
        "close": 100.0,
        "volume": int(VOLUME_ABS_MIN * 2),
        "ema_fast": 101.0,
        "ema_slow": 100.0,
        "rsi": 50.0,
        "adx": ADX_MIN,
        "momentum": MOMENTUM_MIN,
        "vol_avg": VOLUME_ABS_MIN,
        "percentile_high": 110.0,
        "percentile_low": 90.0,
    }
    defaults.update(kw)
    return defaults


class TestAnalyzeSignal:
    def test_long_ideal(self):
        assert analyze_signal(_ind()) == "LONG"

    def test_short_ideal(self):
        assert analyze_signal(_ind(ema_fast=99.0, ema_slow=100.0)) == "SHORT"

    def test_neutral_missing_ema(self):
        assert analyze_signal(_ind(ema_fast=None)) == "NEUTRAL"

    def test_neutral_missing_rsi(self):
        assert analyze_signal(_ind(rsi=None)) == "NEUTRAL"

    def test_long_blocked_rsi_too_high(self):
        assert analyze_signal(_ind(rsi=RSI_OVERBOUGHT_FILTER + 1)) == "NEUTRAL"

    def test_long_blocked_rsi_too_low(self):
        assert analyze_signal(_ind(rsi=RSI_OVERSOLD - 1)) == "NEUTRAL"

    def test_short_blocked_rsi_too_high(self):
        assert analyze_signal(_ind(ema_fast=99.0, ema_slow=100.0, rsi=RSI_OVERBOUGHT_FILTER + 1)) == "NEUTRAL"

    def test_blocked_low_volume(self):
        assert analyze_signal(_ind(volume=VOLUME_ABS_MIN - 1)) == "NEUTRAL"

    def test_blocked_volume_multiplier(self):
        va = 1000
        vol = int(va * VOLUME_MULTIPLIER - 1)
        assert analyze_signal(_ind(vol_avg=va, volume=vol)) == "NEUTRAL"

    def test_blocked_adx(self):
        assert analyze_signal(_ind(adx=ADX_MIN - 1)) == "NEUTRAL"

    def test_adx_none_still_allows(self):
        assert analyze_signal(_ind(adx=None)) == "LONG"

    def test_blocked_momentum(self):
        assert analyze_signal(_ind(momentum=MOMENTUM_MIN / 2)) == "NEUTRAL"

    def test_momentum_none_still_allows(self):
        assert analyze_signal(_ind(momentum=None)) == "LONG"

    def test_long_blocked_by_percentile_high(self):
        assert analyze_signal(_ind(close=115.0, percentile_high=110.0)) == "NEUTRAL"

    def test_short_blocked_by_percentile_low(self):
        assert analyze_signal(_ind(ema_fast=99.0, ema_slow=100.0, close=85.0, percentile_low=90.0)) == "NEUTRAL"
