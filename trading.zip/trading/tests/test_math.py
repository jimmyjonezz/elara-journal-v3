import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["BOT_TICKER"] = "CCM6"

from shared import qfloat
from bot import calc_pnl, calc_commission, pnl_pct_for


class TestQfloat:
    def test_none(self):
        assert qfloat(None) == 0.0

    def test_int(self):
        assert qfloat(123) == 123.0

    def test_float(self):
        assert qfloat(45.5) == 45.5

    def test_moneyvalue_like(self):
        class M:
            units = 100
            nano = 500_000_000

        assert qfloat(M()) == 100.5

    def test_moneyvalue_zero_nano(self):
        class M:
            units = 50
            nano = 0

        assert qfloat(M()) == 50.0

    def test_dict(self):
        assert qfloat({"units": "200", "nano": "250000000"}) == 200.25


class TestCalcPnl:
    def test_long_profit(self):
        assert calc_pnl("LONG", 100, 110, 1, 1, 10) == 100.0

    def test_long_loss(self):
        assert calc_pnl("LONG", 100, 90, 1, 1, 10) == -100.0

    def test_short_profit(self):
        assert calc_pnl("SHORT", 100, 90, 1, 1, 10) == 100.0

    def test_short_loss(self):
        assert calc_pnl("SHORT", 100, 110, 1, 1, 10) == -100.0

    def test_zero_entry(self):
        assert calc_pnl("LONG", 0, 100, 1, 1, 10) == 0.0

    def test_zero_tick_size(self):
        assert calc_pnl("LONG", 100, 110, 1, 0, 10) == 0.0

    def test_multiple_lots(self):
        assert calc_pnl("LONG", 100, 110, 3, 1, 10) == 300.0


class TestCalcCommission:
    def test_basic(self):
        assert calc_commission(100, 10, 1, 0.01) == 0.1

    def test_multiple_lots(self):
        assert calc_commission(100, 10, 5, 0.01) == 0.5

    def test_zero_rate(self):
        assert calc_commission(100, 10, 1, 0) == 0.0

    def test_zero_price(self):
        assert calc_commission(0, 10, 1, 0.01) == 0.0


class TestPnlPctFor:
    def test_long_profit(self):
        assert pnl_pct_for("LONG", 100, 110) == 10.0

    def test_long_loss(self):
        assert pnl_pct_for("LONG", 100, 90) == -10.0

    def test_short_profit(self):
        assert pnl_pct_for("SHORT", 100, 90) == 10.0

    def test_short_loss(self):
        assert pnl_pct_for("SHORT", 100, 110) == -10.0

    def test_zero_entry(self):
        assert pnl_pct_for("LONG", 0, 100) == 0.0
