import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["BOT_TICKER"] = "CCM6"

from datetime import datetime, timezone
import shared
from shared import log_candle, load_candles_from_log, log_trade


class TestLogCandle:
    def test_log_and_load(self, monkeypatch, tmp_path):
        monkeypatch.setattr(shared, "CANDLE_LOG_DIR", tmp_path)

        class MockCandle:
            time = datetime(2026, 5, 31, 10, 0, tzinfo=timezone.utc)
            open = type("q", (), {"units": 100, "nano": 0})()
            high = type("q", (), {"units": 105, "nano": 0})()
            low = type("q", (), {"units": 99, "nano": 0})()
            close = type("q", (), {"units": 102, "nano": 500_000_000})()
            volume = 123

        log_candle(MockCandle())
        loaded = load_candles_from_log("2026-05-31")
        assert len(loaded) == 1
        assert loaded[0].time == MockCandle.time
        assert loaded[0].open == 100.0
        assert loaded[0].high == 105.0
        assert loaded[0].low == 99.0
        assert loaded[0].close == 102.5
        assert loaded[0].volume == 123

    def test_log_multiple(self, monkeypatch, tmp_path):
        monkeypatch.setattr(shared, "CANDLE_LOG_DIR", tmp_path)

        class MockCandle:
            pass

        for i in range(3):
            c = MockCandle()
            c.time = datetime(2026, 5, 31, 10 + i, 0, tzinfo=timezone.utc)
            c.open = c.high = c.low = c.close = type("q", (), {"units": 100 + i, "nano": 0})()
            c.volume = 10 + i
            log_candle(c)
        loaded = load_candles_from_log("2026-05-31")
        assert len(loaded) == 3
        assert [c.volume for c in loaded] == [10, 11, 12]

    def test_load_nonexistent_date(self, monkeypatch, tmp_path):
        monkeypatch.setattr(shared, "CANDLE_LOG_DIR", tmp_path)
        assert load_candles_from_log("2099-01-01") == []


class TestLogTrade:
    def test_log_trade_creates_file(self, monkeypatch, tmp_path):
        monkeypatch.setattr(shared, "TRADE_LOG_DIR", tmp_path)
        log_trade("OPEN LONG", "FIGI123", "CCM6", 1, 100.0)
        today = datetime.now().strftime("%d%m%Y")
        log_file = tmp_path / f"trades_{today}.log"
        assert log_file.exists()
        content = log_file.read_text(encoding="utf-8")
        assert "OPEN LONG" in content
        assert "CCM6" in content
        assert "100.0" in content

    def test_log_trade_with_pnl(self, monkeypatch, tmp_path):
        monkeypatch.setattr(shared, "TRADE_LOG_DIR", tmp_path)
        today = datetime.now().strftime("%d%m%Y")
        log_file = tmp_path / f"trades_{today}.log"
        log_trade("CLOSE (TP)", "FIGI123", "CCM6", 1, 110.0, 50.0)
        content = log_file.read_text(encoding="utf-8")
        assert "P/L: 50.00" in content
