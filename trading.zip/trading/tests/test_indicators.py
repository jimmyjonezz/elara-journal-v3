import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["BOT_TICKER"] = "CCM6"

from datetime import datetime, timezone, timedelta
from bot import (
    calc_ema,
    calc_rsi,
    calc_adx,
    calc_momentum,
    calc_volume_avg,
    calc_bollinger,
    calc_percentile,
    detect_market_from_candles,
    compute_indicators,
)


class TestCalcEma:
    def test_basic(self):
        result = calc_ema([10, 20, 30, 40, 50], 3)
        assert result == 40.0

    def test_two_period(self):
        result = calc_ema([100, 200, 300], 2)
        k = 2 / 3
        ema = (100 + 200) / 2
        ema = 300 * k + ema * (1 - k)
        assert result == ema

    def test_insufficient_data(self):
        assert calc_ema([1, 2], 5) is None

    def test_single_value(self):
        assert calc_ema([10], 3) is None


class TestCalcRsi:
    def test_all_gains(self):
        prices = list(range(10, 26))
        assert calc_rsi(prices, 14) == 100.0

    def test_all_losses(self):
        prices = list(range(25, 9, -1))
        assert calc_rsi(prices, 14) == 0.0

    def test_insufficient_data(self):
        assert calc_rsi([1, 2, 3], 14) is None

    def test_flat(self):
        prices = [50] * 20
        assert calc_rsi(prices, 14) == 100.0


class TestCalcAdx:
    def test_strong_trend(self):
        highs = [float(i) for i in range(20, 50)]
        lows = [float(i - 1) for i in range(20, 50)]
        closes = [float(i - 0.5) for i in range(20, 50)]
        result = calc_adx(highs, lows, closes, 14)
        assert result is not None
        assert result > 15

    def test_flat(self):
        highs = [100.0] * 30
        lows = [99.0] * 30
        closes = [99.5] * 30
        result = calc_adx(highs, lows, closes, 14)
        assert result is not None
        assert result == 0.0

    def test_insufficient_data(self):
        assert calc_adx([1], [1], [1], 14) is None


class TestCalcMomentum:
    def test_up(self):
        assert calc_momentum([100, 100, 103], 2) == 3.0

    def test_down(self):
        result = calc_momentum([100, 100, 97], 2)
        assert result == -3.0

    def test_flat(self):
        assert calc_momentum([100, 100, 100], 2) == 0.0

    def test_insufficient_data(self):
        assert calc_momentum([100], 2) is None


class TestCalcVolumeAvg:
    def test_basic(self):
        assert calc_volume_avg([100, 200, 300], 20) == 200.0

    def test_shorter_than_period(self):
        assert calc_volume_avg([50, 100], 20) == 75.0

    def test_empty(self):
        assert calc_volume_avg([], 20) == 0.0


class TestCalcBollinger:
    def test_flat(self):
        lower, mid, upper = calc_bollinger([50.0] * 20, 20, 2)
        assert lower == 50.0
        assert mid == 50.0
        assert upper == 50.0

    def test_insufficient_data(self):
        lower, mid, upper = calc_bollinger([1, 2, 3], 20, 2)
        assert all(x is None for x in (lower, mid, upper))


class TestCalcPercentile:
    def test_95th(self):
        assert calc_percentile(list(range(1, 101)), 95) == 96

    def test_5th(self):
        assert calc_percentile(list(range(1, 101)), 5) == 6

    def test_empty(self):
        assert calc_percentile([], 95) is None


class TestDetectMarketFromCandles:
    def make_candle(self, age_minutes):
        class MockCandle:
            time = datetime.now(timezone.utc) - timedelta(minutes=age_minutes)

        return MockCandle()

    def test_open_recent(self):
        c = self.make_candle(1)
        assert detect_market_from_candles([c]) is True

    def test_closed_old(self):
        c = self.make_candle(30)
        assert detect_market_from_candles([c]) is False

    def test_empty_candles(self):
        assert detect_market_from_candles([]) is False


class TestComputeIndicators:
    def test_basic(self):
        class MockCandle:
            def __init__(self, close_, high_, low_, vol_):
                self.close = type("cq", (), {"units": close_, "nano": 0})()
                self.high = type("cq", (), {"units": high_, "nano": 0})()
                self.low = type("cq", (), {"units": low_, "nano": 0})()
                self.volume = vol_
                self.time = datetime.now(timezone.utc)

        candles = [MockCandle(i, i + 1, i - 1, 100) for i in range(50)]
        result = compute_indicators(candles)
        assert result["close"] is not None
        assert result["ema_fast"] is not None
        assert result["rsi"] is not None
        assert isinstance(result["volume"], int)
