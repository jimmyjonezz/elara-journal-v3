import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["BOT_TICKER"] = "CCM6"

from bot import calc_ema, calc_rsi, calc_adx
from backtest import IncEMA, IncRSI, IncADX


class TestIncEMA:
    def test_matches_calc_ema(self):
        prices = [float(i) for i in range(10, 110)]
        expected = calc_ema(prices, 5)
        inc = IncEMA(5)
        for p in prices:
            inc.add(p)
        assert inc.ready(5)
        assert abs(inc.value - expected) < 0.01

    def test_not_ready(self):
        inc = IncEMA(5)
        inc.add(10)
        assert not inc.ready(5)

    def test_ready_after_enough(self):
        inc = IncEMA(3)
        for p in [10, 20, 30, 40]:
            inc.add(p)
        assert inc.ready(3)


class TestIncRSI:
    def test_matches_calc_rsi(self):
        prices = [50 + i + (i % 3 - 1) * 2 for i in range(200)]
        expected = calc_rsi(prices, 14)
        inc = IncRSI(14)
        for p in prices:
            inc.add(p)
        assert inc.ready(14)
        assert abs(inc.value() - expected) < 0.01

    def test_all_gains(self):
        prices = list(range(10, 30))
        expected = calc_rsi(prices, 14)
        inc = IncRSI(14)
        for p in prices:
            inc.add(p)
        assert inc.value() == expected
        assert inc.value() == 100.0

    def test_not_ready(self):
        inc = IncRSI(14)
        inc.add(10)
        assert not inc.ready(14)


class TestIncADX:
    def test_matches_calc_adx(self):
        highs = [float(i) for i in range(20, 50)]
        lows = [float(i - 1) for i in range(20, 50)]
        closes = [float(i - 0.5) for i in range(20, 50)]
        expected = calc_adx(highs, lows, closes, 14)
        inc = IncADX(14)
        for i in range(len(closes)):
            inc.add(highs[i], lows[i], closes[i])
        assert inc.ready(14)
        result = inc.value()
        if expected is not None:
            assert abs(result - expected) < 0.01

    def test_flat(self):
        highs = [100.0] * 30
        lows = [99.0] * 30
        closes = [99.5] * 30
        expected = calc_adx(highs, lows, closes, 14)
        inc = IncADX(14)
        for i in range(len(closes)):
            inc.add(highs[i], lows[i], closes[i])
        assert inc.value() == expected


from backtest import BacktestState, INITIAL_EQUITY


class TestBacktestState:
    def test_default_values(self):
        bs = BacktestState()
        assert bs.side == "NONE"
        assert bs.entry_price == 0.0
        assert bs.entry_time is None
        assert bs.entry_bar == 0
        assert bs.peak_price == 0.0
        assert bs.trailing_active is False
        assert bs.entry_mode == "NORMAL"
        assert bs.entry_sl_pct == 0.0
        assert bs.entry_tp_pct == 0.0
        assert bs.entry_trail_act == 0.0
        assert bs.entry_trail_dist == 0.0
        assert bs.trades == []
        assert bs.equity == INITIAL_EQUITY
        assert bs.peak_equity == INITIAL_EQUITY
        assert bs.max_dd_rub == 0.0

    def test_reset_clears_all_fields(self):
        bs = BacktestState()
        bs.side = "LONG"
        bs.entry_price = 100.0
        bs.entry_time = "some_time"
        bs.entry_bar = 42
        bs.peak_price = 105.0
        bs.trailing_active = True
        bs.entry_mode = "TRAILING"
        bs.entry_sl_pct = 1.2
        bs.entry_tp_pct = 1.5
        bs.entry_trail_act = 0.8
        bs.entry_trail_dist = 0.4
        bs.trades = ["trade1"]
        bs.reset()
        assert bs.side == "NONE"
        assert bs.entry_price == 0.0
        assert bs.entry_time is None
        assert bs.entry_bar == 0
        assert bs.peak_price == 0.0
        assert bs.trailing_active is False
        assert bs.entry_mode == "NORMAL"
        assert bs.entry_sl_pct == 0.0
        assert bs.entry_tp_pct == 0.0
        assert bs.entry_trail_act == 0.0
        assert bs.entry_trail_dist == 0.0
        assert bs.trades == ["trade1"]

    def test_reset_preserves_trades_list(self):
        bs = BacktestState()
        bs.trades = [{"pnl": 100}, {"pnl": -50}]
        bs.reset()
        assert bs.trades == [{"pnl": 100}, {"pnl": -50}]

    def test_reset_from_default(self):
        bs = BacktestState()
        bs.reset()
        assert bs.side == "NONE"

    def test_multiple_resets(self):
        bs = BacktestState()
        for _ in range(5):
            bs.side = "LONG"
            bs.reset()
            assert bs.side == "NONE"

    def test_equity_tracking(self):
        bs = BacktestState()
        assert bs.equity == INITIAL_EQUITY
        assert bs.peak_equity == INITIAL_EQUITY
        assert bs.max_dd_rub == 0.0
        bs.equity = INITIAL_EQUITY + 1000
        assert bs.peak_equity == INITIAL_EQUITY

    def test_side_case_sensitivity(self):
        bs = BacktestState()
        bs.side = "long"
        assert bs.side == "long"
        bs.reset()
        assert bs.side == "NONE"

    def test_none_peak_price_handling(self):
        bs = BacktestState()
        bs.peak_price = 0.0
        assert bs.peak_price == 0.0

    def test_reset_does_not_affect_equity(self):
        bs = BacktestState()
        bs.equity = 50000
        bs.peak_equity = 55000
        bs.max_dd_rub = -5000
        bs.reset()
        assert bs.equity == 50000
        assert bs.peak_equity == 55000
        assert bs.max_dd_rub == -5000

    def test_reset_clears_bar_counters(self):
        bs = BacktestState()
        bs.entry_bar = 999
        bs.reset()
        assert bs.entry_bar == 0
