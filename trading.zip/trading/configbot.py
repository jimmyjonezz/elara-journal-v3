"""
Конфигурация фьючерсного бота (CCM6)
=== ТОКЕНЫ см. .env ===
"""

from dotenv import load_dotenv
import os

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

# === РЕЖИМ ===
SANDBOX = True  # True = песочница, False = реальный счёт
ACCOUNT_ID = ""  # ID счёта (пусто = TINKOFF_ACCOUNT_ID из .env, иначе первый счёт из списка)

# === DEBUG ===
DEBUG = True  # Детальный вывод индикаторов

# === ИНСТРУМЕНТ ===
TICKER = os.getenv("BOT_TICKER") or "CCM6"  # Тикер фьючерса (MOEX Clearing)

# === ИНТЕРВАЛ СВЕЧЕЙ ===
CANDLE_INTERVAL = 1  # 1=1мин, 2=5мин, 3=15мин. Перетирается --interval в backtest.py.
# Бот использует SUBSCRIPTION_INTERVAL_ONE_MINUTE (захардкожен в SDK-подписке, не из конфига).

# === СТРАТЕГИЯ ===
EMA_FAST = 9  # Быстрая EMA
EMA_SLOW = 21  # Медленная EMA
RSI_PERIOD = 14  # Период RSI
RSI_OVERBOUGHT = 70  # RSI перекупленность
RSI_OVERSOLD = 30  # RSI перепроданность
VOLUME_MULTIPLIER = 1.2  # Множитель объёма для spike
MOMENTUM_PERIOD = 6  # Momentum (в барах 5-мин = ~30 мин)

# === ФИЛЬТРЫ ВХОДА ===
MOMENTUM_MIN = 0.005  # Минимум momentum (% от цены) для входа
VOLUME_ABS_MIN = 60  # Мин. абсолютный объём (контрактов)
ADX_MIN = 30  # Мин. ADX (сила тренда)
MAX_SPREAD_PCT = 0  # Макс. спред (% от цены). 0 = выкл. get_order_book перед входом.
MIN_BETWEEN_SL = 900  # Пауза после SL перед новым входом (сек, 30 мин)
MIN_COOLDOWN_SEC = 300  # Пауза после ЛЮБОГО выхода (сек, 10 мин)
MIN_SIGNAL_STREAK = 2  # Сколько свечей подряд сигнал должен держаться до входа

# === EMA NOISE FILTER ===
EMA_MARGIN_PCT = 0.005  # Допуск к EMA cross (%). trend_up = ema_fast > ema_slow × (1 − margin/100).
# 0 = старая логика (любой крест переворачивает тренд)
# 0.005 = 0.5 bp ≈ 0.6 пт при цене 12000 — отсекает шумовые фликеры EMA

RSI_OVERBOUGHT_FILTER = 55  # Запрет LONG если RSI выше этого

# === BB (Bollinger Bands) ===
BB_PERIOD = 20  # Период BB
BB_STD_MULT = 2.0  # Множитель стандартного отклонения
BB_FILTER = True  # Band-edge: LONG при цене у нижней полосы, SHORT у верхней
BB_TOLERANCE = 0.25  # Допустимое отклонение от границы полосы (%).
# 0 = within-bands (LONG при price<=bb_u, SHORT при price>=bb_l)
# >0 = band-edge: LONG требует price около bb_l, SHORT около bb_u (±BB_TOLERANCE%)

# === DI FILTER (Directional Indicator) ===
DI_HARD_BLOCK = False  # Блокировать контр-тренд входы при сильном DI-дисбалансе
DI_THRESHOLD = 15  # Порог разницы DI+ и DI- для блокировки

# === ПЕРЕОПРЕДЕЛЕНИЯ ПО ТИКЕРАМ ===
# Каждый тикер указывает свои параметры явно.
# Параметр не указанный для тикера = берётся из глобального умолчания.
TICKER_PARAMS = {
    "CRM6": {
        "ADX_MIN": 20,
        "STOP_LOSS_PCT": 0.4,
        "TAKE_PROFIT_PCT": 0.6,
        "TRAILING_ACTIVATE": 0.4,
        "TRAILING_DISTANCE": 0.15,
        "VOLUME_MULTIPLIER": 1.1,
        "RSI_OVERBOUGHT_FILTER": 60,
        "MOMENTUM_PERIOD": 3,
        "COMMISSION_PCT": 0.00462,
        "MIN_BETWEEN_SL": 1800,
    },
    "CCM6": {
        "STOP_LOSS_PCT": 1.2,
        "TAKE_PROFIT_PCT": 1.5,
        "TRAILING_ACTIVATE": 0.8,
        "TRAILING_DISTANCE": 0.4,
        "VOLUME_MULTIPLIER": 1.2,
        "ADX_MIN": 30,
        "RSI_OVERBOUGHT_FILTER": 55,
        "MOMENTUM_PERIOD": 6,
        "COMMISSION_PCT": 0.01320,
        "MIN_BETWEEN_SL": 1800,
        "MOMENTUM_MIN": 0.005,
        "VOLUME_ABS_MIN": 60,
        "MIN_COOLDOWN_SEC": 600,
    },
    "GDM6": {
        "STOP_LOSS_PCT": 0.3,
        "TAKE_PROFIT_PCT": 0.5,
        "TRAILING_ACTIVATE": 0.3,
        "TRAILING_DISTANCE": 0.15,
        "VOLUME_MULTIPLIER": 1.2,
        "ADX_MIN": 25,
        "RSI_OVERBOUGHT_FILTER": 55,
        "MOMENTUM_PERIOD": 6,
        "COMMISSION_PCT": 0.01320,
        "MIN_BETWEEN_SL": 1800,
        "MOMENTUM_MIN": 0.005,
        "VOLUME_ABS_MIN": 20,
        "MIN_COOLDOWN_SEC": 600,
    },
    "SVM6": {
        "STOP_LOSS_PCT": 1.2,
        "TAKE_PROFIT_PCT": 1.5,
        "TRAILING_ACTIVATE": 0.8,
        "TRAILING_DISTANCE": 0.4,
        "VOLUME_MULTIPLIER": 1.2,
        "ADX_MIN": 25,
        "RSI_OVERBOUGHT_FILTER": 55,
        "MOMENTUM_PERIOD": 6,
        "COMMISSION_PCT": 0.01320,
        "MIN_BETWEEN_SL": 1800,
        "MOMENTUM_MIN": 0.005,
        "VOLUME_ABS_MIN": 20,
        "MIN_COOLDOWN_SEC": 600,
    },
    "NGM6": {
        "STOP_LOSS_PCT": 1.2,
        "TAKE_PROFIT_PCT": 1.5,
        "TRAILING_ACTIVATE": 0.8,
        "TRAILING_DISTANCE": 0.4,
        "VOLUME_MULTIPLIER": 1.2,
        "ADX_MIN": 25,
        "RSI_OVERBOUGHT_FILTER": 55,
        "MOMENTUM_PERIOD": 6,
        "COMMISSION_PCT": 0.01320,
        "MIN_BETWEEN_SL": 1800,
        "MOMENTUM_MIN": 0.005,
        "VOLUME_ABS_MIN": 20,
        "MIN_COOLDOWN_SEC": 600,
    },
    "SRM6": {
        "STOP_LOSS_PCT": 1.2,
        "TAKE_PROFIT_PCT": 1.5,
        "TRAILING_ACTIVATE": 0.8,
        "TRAILING_DISTANCE": 0.4,
        "VOLUME_MULTIPLIER": 1.2,
        "ADX_MIN": 22,
        "RSI_OVERBOUGHT_FILTER": 55,
        "MOMENTUM_PERIOD": 6,
        "COMMISSION_PCT": 0.00132,
        "MIN_BETWEEN_SL": 1800,
        "MOMENTUM_MIN": 0.005,
        "VOLUME_ABS_MIN": 10,
        "MIN_COOLDOWN_SEC": 600,
    },
    "GZM6": {
        "STOP_LOSS_PCT": 1.2,
        "TAKE_PROFIT_PCT": 1.5,
        "TRAILING_ACTIVATE": 0.8,
        "TRAILING_DISTANCE": 0.4,
        "VOLUME_MULTIPLIER": 1.2,
        "ADX_MIN": 22,
        "RSI_OVERBOUGHT_FILTER": 55,
        "MOMENTUM_PERIOD": 6,
        "COMMISSION_PCT": 0.00132,
        "MIN_BETWEEN_SL": 600,
        "MOMENTUM_MIN": 0.005,
        "VOLUME_ABS_MIN": 10,
        "MIN_COOLDOWN_SEC": 600,
        "MIN_SIGNAL_STREAK": 2,
        "DI_HARD_BLOCK": True,
        "DI_THRESHOLD": 15,
    },
    "NAM6": {
        "STOP_LOSS_PCT": 1.2,
        "TAKE_PROFIT_PCT": 1.5,
        "TRAILING_ACTIVATE": 0.8,
        "TRAILING_DISTANCE": 0.4,
        "VOLUME_MULTIPLIER": 1.2,
        "ADX_MIN": 25,
        "RSI_OVERBOUGHT_FILTER": 55,
        "MOMENTUM_PERIOD": 6,
        "COMMISSION_PCT": 0.00462,
        "MIN_BETWEEN_SL": 1800,
        "MOMENTUM_MIN": 0.005,
        "VOLUME_ABS_MIN": 10,
        "MIN_COOLDOWN_SEC": 600,
        "MIN_SIGNAL_STREAK": 1,
        "LEVERAGE_FACTOR": 0.70,
        "DI_HARD_BLOCK": True,
        "DI_THRESHOLD": 15,
    },
    "S1M6": {
        "STOP_LOSS_PCT": 1.2,
        "TAKE_PROFIT_PCT": 1.5,
        "TRAILING_ACTIVATE": 0.8,
        "TRAILING_DISTANCE": 0.4,
        "VOLUME_MULTIPLIER": 1.2,
        "ADX_MIN": 25,
        "RSI_OVERBOUGHT_FILTER": 55,
        "MOMENTUM_PERIOD": 6,
        "COMMISSION_PCT": 0.01320,
        "MIN_BETWEEN_SL": 1800,
        "MOMENTUM_MIN": 0.005,
        "VOLUME_ABS_MIN": 10,
        "MIN_COOLDOWN_SEC": 600,
    },
    "GLDRUBF": {
        "STOP_LOSS_PCT": 1.2,
        "TAKE_PROFIT_PCT": 1.5,
        "TRAILING_ACTIVATE": 0.8,
        "TRAILING_DISTANCE": 0.4,
        "VOLUME_MULTIPLIER": 1.2,
        "ADX_MIN": 22,
        "RSI_OVERBOUGHT_FILTER": 55,
        "MOMENTUM_PERIOD": 6,
        "COMMISSION_PCT": 0.01320,
        "MIN_BETWEEN_SL": 1800,
        "MOMENTUM_MIN": 0.005,
        "VOLUME_ABS_MIN": 10,
        "MIN_COOLDOWN_SEC": 600,
        "MIN_SIGNAL_STREAK": 3,
    },
}

# === ПРОЦЕНТИЛЬНЫЙ ФИЛЬТР ===
PERCENTILE_DAYS = 5  # Окно истории (дней) для расчёта процентилей
PERCENTILE_FILTER = 100  # LONG блокируется выше этого процентиля.
# SHORT блокируется ниже (100-PERCENTILE_FILTER)-го.
# 100 = max за 5 дней → фильтр мёртв (цена почти никогда не попадает в max)
# 95 = блокирует вход в top 5% диапазона (полезно)
# 0 = выключено

# === РИСК-МЕНЕДЖМЕНТ ===
RISK_PERCENT = 1.0  # Риск на сделку (% от депозита)
INITIAL_EQUITY = 40000.0  # Фиксированный стартовый депозит для расчёта лотов
LOT = 0  # 0 = авто (через LEVERAGE_FACTOR), >0 = фиксированный.
# При LOT=0: order_lot = max(1, int(INITIAL_EQUITY * LEVERAGE_FACTOR / notional))
# При LOT>0: order_lot = LOT (переопределяет LEVERAGE_FACTOR)
LEVERAGE_FACTOR = 1.0  # Доля депозита на 1 контракт (0.5 = 50%, 1.0 = 100%).
# При LEVERAGE_FACTOR=1.0 LOT=2 на GZM6 (notional 13k, equity 40k) — плечо ~0.65x.
# При LEVERAGE_FACTOR=2.0 LOT=5 — плечо ~1.7x.
STOP_LOSS_PCT = 1.2  # Стоп-лосс (%)
TAKE_PROFIT_PCT = 1.5  # Тейк-профит (%)
COMMISSION_PCT = 0.0  # Комиссия (% от оборота), переопределяется в TICKER_PARAMS

# === TRAILING STOP ===
TRAILING_ACTIVATE = 0.8  # Активация trailing при росте (%)
TRAILING_DISTANCE = 0.4  # Дистанция trailing (% от пика)

# === TREND-FOLLOWING COMPANION ===
# Активируется когда основная стратегия = NEUTRAL.
# Ловит трендовые дни (типа 02.06) где нет отката к BB.
TREND_FOLLOWING_ENABLED = False
TF_ADX_MIN = 30  # Минимум ADX для определения сильного тренда
TF_EMA_SLOPE_MIN = 0.001  # 0.1% — ema_fast должен отстоять от ema_slow
TF_PULLBACK_PCT = 0.0015  # Вход при откате цены к ema_fast (±0.15%)
TF_TP_PCT = 2.5  # Take profit (%)
TF_SL_PCT = 1.5  # Stop loss (%)
TF_TRAIL_ACT_PCT = 1.0  # Trailing activation
TF_TRAIL_DIST_PCT = 0.5  # Trailing distance
TF_MIN_STREAK = 2  # Свечей подряд для входа
TF_MOMENTUM_MIN = 0.3  # Momentum 6-bar (≥ 0.3% / 6 мин)
TF_RSI_LOW = 35  # RSI не ниже (не short в перепроданности)
TF_RSI_HIGH = 65  # RSI не выше (не long в перекупленности)

# === СЕРВЕР ===
SERVER_PORT = 5000  # Порт дашборда

# === ВРЕМЯ ===
TIME_FILTER_HOUR = 19  # Запрет входа после этого часа (МСК)
PRELOAD_HOURS = 0  # 0 = загрузить свечи с начала торговой сессии (через API trading_schedules)
# >0 = загрузить последние N часов (например, 6 = 6ч ~= 360 свечей 1мин)

# === РЕАЛЬНАЯ ТОРГОВЛЯ ===
MAX_DAILY_LOSS_PCT = 3.0  # Стоп торговли на день при просадке > 3%
MAX_CONSECUTIVE_LOSSES = 2  # Circuit breaker после N убытков подряд
PRICE_DEVIATION_MAX_PCT = 5.0  # Макс. отклонение цены для sanity check
MIN_CASH_BUFFER_PCT = 50  # Буфер ГО при входе (% сверху)
CIRCUIT_BREAKER_COOLDOWN = 3600  # Сброс circuit breaker через N секунд
