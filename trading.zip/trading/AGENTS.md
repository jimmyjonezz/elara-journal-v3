# AGENTS.md — CCM6 Trading Bot

## Быстрый старт

| Команда | Назначение |
|---------|-----------|
| `python bot --ticker TICKER` | Запуск бота без дашборда |
| `python server.py --ticker TICKER` | Запуск сервера + бот (sandbox, порт 5000) |
| `python server.py --ticker TICKER --mode real` | Запуск сервера + реальная торговля |
| `python backtest.py --ticker TICKER` | Бэктест (c 1-мин свечами) |
| `python backtest.py --ticker TICKER --days 14 --interval 1` | Бэктест с кастомным периодом |
| `python run_briefing.py` | Генерация аналитического брифинга |

Зависимости устанавливаются вручную: `pip install fastapi uvicorn aiohttp python-dotenv`.
- Новых зависимостей не требуется — все изменения Phases 1–3 без добавления пакетов.

## Архитектура

- Один процесс: `server.py` (FastAPI :5000 + бот в daemon-потоке, `--mode sandbox|real`)
- Lifecycle бота: `threading.Event` в `shared.py`. `/api/bot/stop` → `.clear()`, `/api/bot/start` → `.set()`
- Общее состояние: singleton `shared.state` класса `BotState` (dataclass)

## Конфигурация

- **configbot.py** — параметры стратегии, режим (песочница/реал), риск-менеджмент, `SERVER_PORT = 5000`
- **.env** — токены (не коммитить)
- `SANDBOX = True` — работа через `client.sandbox.sandbox_pay_in()` + `client.orders.post_order()`
- `SANDBOX = False` → используется `TINKOFF_TOKEN` (реальная торговля через `real_trader.py`)
- `PRELOAD_HOURS = 0` — загрузка свечей с начала сессии через `trading_schedules` API, fallback 48h

## Tinkoff API (gRPC через SDK t-tech-investments)

- SDK: `pip install t-tech-investments>=1.49.0 --index-url https://opensource.tbank.ru/api/v4/projects/238/packages/pypi/simple`
- Импорт: `from t_tech.invest import AsyncClient, CandleInstrument, ...` (типы), `from t_tech.invest.constants import ...` (константы), `from t_tech.invest.exceptions import AioRequestError`
- Контекстный менеджер: `async with AsyncClient(token, target=..., app_name=...) as client:`
- `client` на самом деле `AsyncServices` из `t_tech.invest.async_services`
- Ордера: `client.orders.post_order(figi=..., quantity=..., direction=..., account_id=..., order_type=..., order_id=..., instrument_id=...)` — **только keyword-only**
- Свечи истории: `client.get_all_candles(from_=..., to=..., interval=1, figi=...)` → async iterable `HistoricCandle` (есть `is_complete`)
- Свечи стрима: `AsyncMarketDataStreamManager` + `manager.candles.waiting_close(True).subscribe([CandleInstrument(instrument_id=uid, ...)])`; `manager.info.subscribe([InfoInstrument(instrument_id=uid)])`; `md.candle` → `Candle` (НЕТ `is_complete`)
- Статус торгов: `client.market_data.get_trading_status(figi=...)` → `TradingStatus` (поля: `trading_status`, `market_order_available_flag`, `limit_order_available_flag`, НЕТ `api_trade_available_flag`)
- Sandbox pay-in: `client.sandbox.sandbox_pay_in(account_id=..., amount=MoneyValue(currency="rub", units=..., nano=0))`
- Конвертация цен: `qfloat(q) = q.units + q.nano / 1e9` — работает для `Quotation` и `MoneyValue`
- Стрим: `AsyncMarketDataStreamManager` с auto-reconnect (exponential backoff) и auto-resubscribe; `instrument_id=uid` предпочтительнее `figi=figi`

## Дашборд

- Порт задаётся в `configbot.py` (`SERVER_PORT`, по умолчанию 5000)
- HTML-дашборд: `templates/index.html` (TradingView Lightweight Charts)
- SSE: `/api/events` — push-обновления состояния
- Кнопки: Start / Stop / Close Pos / Open Long / Open Short
- **XSS fix**: `TICKER` экранируется через `json.dumps()` вместо f-строки (`bot_api.py:169`)

## Брифинг (briefing.py)

- Использует gRPC SDK (`AsyncClient`) для свечей, aiohttp только для `/api/status` бота
- Принимает опциональный `client` параметр от `bot.py` для переиспользования соединения
- Шаблонный анализ (RSI, MACD, Bollinger) — без LLM
- Результаты: `briefings/briefing_{YYYY-MM-DD}.json`
- Триггеры: смена сигнала (LONG/SHORT → NEUTRAL и наоборот), ручной `python run_briefing.py`
- **`_safe_briefing()`**: защита от накопления параллельных задач брифинга через глобальный флаг (`bot.py:83-97`)

## Логи и данные

- Сделки: `logs/trades_{DDMMYYYY}.log` — парсится по шаблону `P/L:\s*([+-]?[\d.]+)`
- Портфель: `logs/portfolio_{DDMMYYYY}.log`
- Статистика при старте загружается из логов (`load_stats_from_logs`)
- **Console log API**: `/api/logs` читает `logs/console_YYYYMMDD.log`
- **`CandleLog` dataclass**: в `shared.py` заменил `type("CandleLog", (), {...})()` в `load_candles_from_log()` — type hints + IDE-автокомплит

## Рынок

- Статус определяется динамически: `trading_status` из стрима (`NORMAL_TRADING` || `market_order_available_flag` || `limit_order_available_flag`) + возраст последней свечи ≤ 10 мин как fallback
- Клиринг (14:00–14:03 МСК) — трейдинг-статус уходит из NORMAL_TRADING, бот не входит

## Смена тикера

- `python server.py --ticker CRM6` — сервер с CNY-6.26
- `python backtest.py --ticker CRM6` — бэктест CNY-6.26 (кеш в `history/`, инкрементальные индикаторы)
- `python bot.py --ticker CRM6` — бот напрямую
- Параметры стратегии переопределяются автоматически через `TICKER_PARAMS` в `configbot.py`

## Бэктест

- **Кеш**: `history/{ticker}_{interval}_{from}_{to}.json` — создаётся при первом API-запросе, при повторном запуске грузится локально
- **Инкрементальные индикаторы**: `IncEMA`, `IncRSI`, `IncADX` в `backtest.py` — O(n) вместо O(n²), ~секунда на 10k свечей
- **Датакласс `CachedCandle`**: обёртка для закешированных свечей с теми же аттрибутами (`.time`, `.open`, `.high`, `.low`, `.close`, `.volume`)
- **High/low-based exit**: выход на экстремумах свечи (SL/TP/trailing), а не на close — точнее отражает поведение лимитных ордеров
- **Per-trade TP/SL/Trailing**: `BacktestState.entry_sl_pct` и т.д. — позволяет разным режимам входа использовать свои параметры выхода
- **`indicators.py`**: pure-math индикаторы (EMA, RSI, ADX, Bollinger, momentum) вынесены в общий файл из `bot.py`/`backtest.py`/`briefing.py`

### GZM6 — 30 days (10.04–03.06, 1-min, LOT=1, LEVERAGE_FACTOR=0.5):
- 32 trades, 24W/8L, **75.0% WR**, PF 1.67, +827 RUB (+2.07%)
- Monte Carlo: 90.8% profitable, DD 95% = 2.16%
- Sharpe: 4.41, Max DD: 1.38%

### GZM6 — 60 days (13.04–12.06, 1-min, LOT=3, LEVERAGE_FACTOR=1.0):
- **DI_HARD_BLOCK=15**: 44 trades, 30W/14L, **68.2% WR**, PF **1.31**, +1854 RUB (+4.63%)
- MC 79.8%, Sharpe 1.99, Max DD 4.42%
- Без DI-фильтра: PF 1.21, +1369 RUB — **DI даёт +485 RUB**

### NAM6 — 60 days (09.04–12.06, 1-min, LOT=1, LEVERAGE_FACTOR=0.70, ADX=25, streak=1):
- **DI_HARD_BLOCK=15**: 50 trades, 37W/13L, **74.0% WR**, PF **1.92**, +2881 RUB (+7.20%)
- MC 98.1%, Sharpe 5.61, Max DD 1.76%
- Без DI-фильтра: PF 1.75, +2531 RUB — **DI даёт +350 RUB**

### GLDRUBF — 90 days (13.03–11.06, 1-min, LOT=3, LEVERAGE_FACTOR=1.0, ADX=22, **streak=3**):
- 33 trades, 26W/7L, **78.8% WR**, PF 2.44, +4274 RUB (+10.68%)
- MC 98.9%, DD 95% = 4.64%, Sharpe 7.61
- Walk-forward 45d/45d: PF 2.24→2.74 (улучшение, не overfit)
- Trail=1.0 tested: PF 1.76→1.35 (провал WF — overfit)
- **Вывод: streak=3 подтверждён walk-forward. Золото шумнее — нужна более сильная фильтрация.**

## Стратегия (ключевые параметры)

- EMA fast/slow = 9/21, RSI(14) oversold 30, overbought 70
- ADX ≥ 30 (в TICKER_PARAMS может быть ниже, например SRM6/GZM6 — 22), momentum ≥ 0.005%, объём ≥ 1.2× от avg (минимум 60 контрактов)
- `abs(momentum)` — **feature не bug**: ловит SHORT при откатах вверх в downtrend. Directional momentum (< 0 для SHORT) ухудшил PF 4.75→2.5 на GZM6 20d.
- Запрет входа после 19:00 МСК (`TIME_FILTER_HOUR = 19`). Вечерняя сессия (19-23:50) даёт больше шума — TIME_FILTER_HOUR=23 ухудшил PF 1.66→1.49
- RSI_OVERBOUGHT_FILTER = 55 — запрет LONG при RSI выше 55
- SL 1.2%, TP 1.5%, Trailing: активация при +0.8%, дистанция 0.4%
- MIN_SIGNAL_STREAK = 2 (global). GZM6 = 2, NAM6 = 1
- MIN_COOLDOWN_SEC = 600 (10 min) после ЛЮБОГО выхода
- **DI_HARD_BLOCK = True** (GZM6, NAM6) — фильтр Directional Indicator: блокирует LONG если DI- > DI+ + 15 (сильный медвежий импульс) и SHORT если DI+ > DI- + 15 (сильный бычий). Отсекает входы, где EMA-тренд не успел развернуться, а high-low импульс уже развернулся.  
  Результаты на GZM6 60d: PF 1.21→1.31 (+485 RUB), NAM6 60d: PF 1.75→1.92 (+350 RUB). Не ухудшает CRM6/CCM6/GLDRUBF.  
  `calc_plus_di()` / `calc_minus_di()` в `indicators.py` (через общий `_calc_di()`).  
  `IncADX.plus_di()` / `IncADX.minus_di()` в `backtest.py`.
- BB_FILTER = True — band-edge mode: LONG требует price у bb_l (±BB_TOLERANCE% = 0.25%), SHORT у bb_u
  - BB_TOLERANCE=0 = within-bands (блокирует вход при price > bb_u для LONG)
  - BB_TOLERANCE=0.25 (default) = band-edge: LONG только при bb_l ≤ price ≤ bb_l × 1.0025
- EMA_MARGIN_PCT = 0.005 — anti-flicker: trend = ef > es × (1 − margin/100)
- PERCENTILE_FILTER = 100 — **фактически выключен**: 100-й перцентиль = max за 5 дней, блокирует только при точном попадании в 5d-max
- **SHORT TP bug fix** (Phase 1): `backtest.py:632` использует `bt.entry_tp_pct` вместо `TAKE_PROFIT_PCT` для SHORT — корректно с trend-following mode
- PRELOAD_HOURS = 0 — загрузка свечей с начала торговой сессии (через API trading_schedules, fallback 48h)
- LOT = 0 — фиксированное количество контрактов (0 = авто через LEVERAGE_FACTOR, >0 = переопределяет LEVERAGE_FACTOR)
- LEVERAGE_FACTOR = 1.0 — доля депозита на 1 контракт. LOT = max(1, int(EQUITY × LEVERAGE_FACTOR / notional))
- INITIAL_EQUITY = 40000 — фиксированная база для LOT, а не динамический баланс счёта
- MIN_WARMUP_CANDLES = 100 — загрузка 48h при старте, если свечей меньше 100 (защита от EMA=0)
- TREND_FOLLOWING_ENABLED = False (отключён по умолчанию — тест ухудшил PF 1.66→1.33 на GZM6 60d)
- TIME_FILTER_HOUR = 19 (оставлен — вечерняя сессия ухудшает результаты)
- MAX_SPREAD_PCT = 0 (выкл) — при >0 делает get_order_book(depth=1) перед входом, блокирует если спред шире порога

## Termux (Android)

- **Скрипт**: `bash termux_start.sh help` — смотреть команды
- **Установка**: `bash termux_start.sh install` — ставит tmux, rust, protobuf, pip пакеты
- **Запуск с tmux**: `bash termux_start.sh tmux` — бот в tmux-сессии, не умирает при закрытии Termux
- **Wake lock**: автоматически захватывается и отпускается при выходе
- **Дашборд**: `http://localhost:5000/` в браузере Android
- **Для фоновой работы**: отключить battery optimization для Termux (Настройки → Батарея → Исключения)

## Безопасность

- **`globals()` whitelist**: `TICKER_PARAMS` применяются только через whitelist из 17 ключей. Неизвестные ключи игнорируются с предупреждением (`bot.py:537-561`)
- **API auth middleware**: все `/api/*` проверяют `Authorization: Bearer <token>` из `API_TOKEN` в `.env`. Пустой токен = auth выключен (обратная совместимость) (`bot_api.py:30-36`)
- **Custom error handler**: все исключения FastAPI → `{"error": "Internal server error"}`, внутренние пути не утекают (`bot_api.py:39-41`)
- **SSE disconnect detection**: `/api/events` проверяет `request.is_disconnected()`, зомби-корутины умирают при отключении клиента (`bot_api.py:443+`)
- **innerHTML → DOM API**: дашборд не использует `innerHTML` для данных — только `createElement` + `textContent` (XSS-safe)
- **Circuit breaker**: `MAX_CONSECUTIVE_LOSSES=2` → после 2 убытков подряд блокировка входа на `CIRCUIT_BREAKER_COOLDOWN=3600с`. Счётчик сбрасывается при прибыльной сделке (`shared.py`, `bot.py`)
- **Manual entry guard**: ручной вход проверяет `TIME_FILTER_HOUR` + price sanity (10× recent range) (`bot.py:1205-1218`)
- **Path traversal fix**: `parse_trades_log()` валидирует `date_str` через `re.fullmatch(r"\d{8}", ...)` (`bot_api.py:52`)
- **GET auth**: все `/api/*` эндпоинты защищены (не только POST) (`bot_api.py:32`)
- **`release_operation_lock()` guard**: try/except RuntimeError при двойном release (`shared.py:347-351`)

## Консольный лог

- **`init_console_logging()`** — idempotent, guard `_console_logging_initialized` от двойного вызова (`shared.py:53-65`)
- **Файл**: `logs/console_YYYYMMDD.log` (append), один файл на день
- **`_Tee`**: дублирует `print()` и `sys.stderr` в терминал + лог-файл. Есть `isatty()`, `fileno()`, `encoding` для совместимости с uvicorn

## Инструменты

- **Линтер/форматтер**: `ruff check . && ruff format .` (конфиг `pyproject.toml`)
- **Зависимости**: `pip install -r requirements.txt`
- **Очистка кеша history/**: `python merge_history.py`
- **Git**: не репозиторий (папка `.git` есть, но git.exe недоступен в PATH)
- **Тесты**: `tests/` (112 тестов, 7 файлов), запуск `python -m pytest tests -v`

## Краевые случаи в тестах

### RateLimiter (9 тестов, `tests/test_api.py`)
- Zero max_calls, exhausted bucket, burst, concurrent acquire, partial refill, long period wait

### is_definitive (16 тестов, `tests/test_api.py`)
- Все комбинации ошибок: 30079, 30042, not available, instrument not found, case insensitive, unicode, non-AioRequestError, None

### BacktestState (10 тестов, `tests/test_backtest.py`)
- Default values, reset (полный, частичный, множественный), сохранение trades/equity при reset
