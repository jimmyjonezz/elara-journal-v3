"""Запускает server.py с тикером GZM6 ровно в 09:00 (по времени ПК)."""

import subprocess
import sys
import time
from datetime import datetime, timedelta

TARGET_HOUR, TARGET_MINUTE = 9, 0
WORKDIR = r"C:\Users\ggotm\Desktop\trading"
COMMAND = [sys.executable, "server.py", "--ticker", "NAM6"]


def next_run(now: datetime) -> datetime:
    candidate = now.replace(hour=TARGET_HOUR, minute=TARGET_MINUTE, second=0, microsecond=0)
    if candidate <= now:
        candidate += timedelta(days=1)
    return candidate


def main() -> None:
    print(f"[run] ожидание до {TARGET_HOUR:02d}:{TARGET_MINUTE:02d} (локальное время ПК)")
    now = datetime.now()
    run_at = next_run(now)
    wait_sec = (run_at - now).total_seconds()
    print(
        f"[run] текущее: {now:%Y-%m-%d %H:%M:%S}  ->  запуск в: {run_at:%Y-%m-%d %H:%M:%S}  (через {wait_sec / 3600:.2f} ч)"
    )

    while datetime.now() < run_at:
        remaining = (run_at - datetime.now()).total_seconds()
        time.sleep(min(60, max(1, remaining)))

    print(f"[run] {datetime.now():%H:%M:%S} — старт: {' '.join(COMMAND)}")
    subprocess.Popen(COMMAND, cwd=WORKDIR)
    print("[run] команда запущена, скрипт завершён")


if __name__ == "__main__":
    main()
