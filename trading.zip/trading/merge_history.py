"""
merge_history.py — merge overlapping history cache files, remove duplicates.

Usage: python merge_history.py [--dry-run]

Scans history/{TICKER}_{INTERVAL}_{FROM}_{TO}.json, groups by TICKER+INTERVAL,
merges all candles, deduplicates by timestamp, writes one file per group.
"""

import json
import re
import sys
from pathlib import Path

HISTORY_DIR = Path(__file__).parent / "history"
FILE_PATTERN = re.compile(r"^(\w+)_(\d+)_(\d{8})_(\d{8})\.json$")
CACHE_GROUP = re.compile(r"^(\w+)_(\d+)_")


def merge():
    dry_run = "--dry-run" in sys.argv

    groups = {}
    for p in sorted(HISTORY_DIR.glob("*.json")):
        m = FILE_PATTERN.match(p.name)
        if not m:
            print(f"  SKIP (no match): {p.name}")
            continue
        ticker, interval, from_str, to_str = m.groups()
        key = f"{ticker}_{interval}"
        groups.setdefault(key, []).append(p)

    total_saved = 0
    total_deleted = 0
    kept = 0

    for key, files in sorted(groups.items()):
        ticker, interval = key.split("_")
        if len(files) <= 1:
            kept += 1
            continue

        print(f"\n{key}: {len(files)} files -> ", end="")
        all_candles = {}
        min_date, max_date = None, None
        for p in files:
            m = FILE_PATTERN.match(p.name)
            fd, td = m.group(3), m.group(4)
            if min_date is None or fd < min_date:
                min_date = fd
            if max_date is None or td > max_date:
                max_date = td
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
            except Exception as e:
                print(f"  error reading {p.name}: {e}")
                sys.exit(1)
            for c in data:
                all_candles[c["t"]] = c
            size_kb = p.stat().st_size / 1024
            total_saved += size_kb
            total_deleted += 1

        merged = sorted(all_candles.values(), key=lambda c: c["t"])
        new_name = f"{key}_{min_date}_{max_date}.json"
        new_path = HISTORY_DIR / new_name
        new_size = len(json.dumps(merged, ensure_ascii=False).encode("utf-8")) / 1024
        total_saved -= new_size
        kept += 1

        print(f"{len(merged)} unique candles -> {new_name} ({new_size:.0f} KB)", end="")
        for p in files:
            print(f"  delete {p.name}")

        if dry_run:
            print("  [DRY RUN]")
            continue

        new_path.write_text(json.dumps(merged, ensure_ascii=False), encoding="utf-8")
        for p in files:
            p.unlink()
        print("  OK")

    total_mb = total_saved / 1024
    print(f"\n{'=' * 50}")
    if dry_run:
        print(f"[DRY RUN] Would delete {total_deleted} files, save ~{total_mb:.1f} MB")
        print(f"New total: {kept} files")
    else:
        print(f"Done: deleted {total_deleted} files, saved ~{total_mb:.1f} MB")
        print(f"New total: {kept} files")


if __name__ == "__main__":
    merge()
