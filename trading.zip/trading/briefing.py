#!/usr/bin/env python3
"""
briefing.py — генерирует аналитический брифинг.
Использует gRPC SDK для свечей, aiohttp только для статуса бота.
"""

import asyncio
import json
import os
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")

BASE_DIR = Path(__file__).parent
BRIEFINGS_DIR = BASE_DIR / "briefings"
BRIEFINGS_DIR.mkdir(exist_ok=True)

from shared import qfloat, get_session_start
from configbot import SERVER_PORT, TICKER as CFG_TICKER, PRELOAD_HOURS
from t_tech.invest import AsyncClient
from indicators import calc_rsi, calc_bollinger

BOT_URL = f"http://127.0.0.1:{SERVER_PORT}"


def load_env():
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                k, v = line.strip().split("=", 1)
                os.environ.setdefault(k, v)


load_env()

TICKER = os.getenv("BOT_TICKER") or CFG_TICKER or "CCM6"

TICKER_NAMES = {
    "CCM6": "COCOA",
    "CRM6": "CNYRUB",
    "GDM6": "GOLD",
    "SVM6": "SILVER",
    "NGM6": "NG",
    "SRM6": "SUGAR",
    "GZM6": "GAZP",
    "GAZR": "GAZP",
    "GLDRUBF": "GOLD-MINI",
}


def calc_atr(candles: list, period: int = 14) -> float:
    if len(candles) < period + 1:
        return 0.0
    trs = []
    for i in range(1, len(candles)):
        hi, lo, pc = candles[i]["high"], candles[i]["low"], candles[i - 1]["close"]
        tr = max(hi - lo, abs(hi - pc), abs(lo - pc))
        trs.append(tr)
    return sum(trs[-period:]) / period


def calc_macd(closes: list, fast: int = 12, slow: int = 26, signal: int = 9):
    if len(closes) < slow + signal:
        return 0.0, 0.0, 0.0

    def ema(data, n):
        k = 2 / (n + 1)
        ema_val = sum(data[:n]) / n
        for v in data[n:]:
            ema_val = v * k + ema_val * (1 - k)
        return ema_val

    e_fast = ema(closes, fast)
    e_slow = ema(closes, slow)
    macd_line = e_fast - e_slow
    signal_line = ema(closes, signal)
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram


def calc_vwap(candles: list) -> float:
    if not candles:
        return 0.0
    sum_pv = 0.0
    sum_v = 0.0
    for c in candles:
        tp = (c["high"] + c["low"] + c["close"]) / 3.0
        vol = c.get("volume", 0) or 0
        sum_pv += tp * vol
        sum_v += vol
    return sum_pv / sum_v if sum_v > 0 else 0.0


# ─── Bot state via HTTP ────────────────────────────────────────
async def get_bot_status() -> dict:
    try:
        import aiohttp

        async with aiohttp.ClientSession() as sess:
            async with sess.get(f"{BOT_URL}/api/status", timeout=aiohttp.ClientTimeout(total=5)) as r:
                if r.status == 200:
                    return await r.json()
    except Exception:
        pass
    return {}


def build_analysis_template(
    price, rsi_val, bb, macd_val, atr_val, position, balance, ticker="CCM6", bot_signal="NEUTRAL"
) -> dict:
    name = TICKER_NAMES.get(ticker, ticker)
    if rsi_val > 70:
        rsi_sent = "перекуплен"
    elif rsi_val < 30:
        rsi_sent = "перепродан"
    else:
        rsi_sent = "нейтральная зона"
    if macd_val > 0:
        macd_sent = "бычий"
    elif macd_val < 0:
        macd_sent = "медвежий"
    else:
        macd_sent = "нейтральный"
    if bb and bb[0] is not None and bb[2] is not None:
        bb_l, bb_m, bb_u = bb
        if price < bb_l:
            bb_pos = "ниже нижней полосы (сильный сигнал на покупку)"
        elif price > bb_u:
            bb_pos = "выше верхней полосы (сильный сигнал на продажу)"
        elif price > bb_m:
            bb_pos = "в верхней половине полос"
        else:
            bb_pos = "в нижней половине полос"
    else:
        bb_pos = "данные BB недоступны"
    sentiment = "bullish" if rsi_val < 50 else "bearish" if rsi_val > 65 else "neutral"
    pos_text = f"Позиция {position} открыта." if position != "NONE" else "Позиция NONE."
    signal_text = f"Сигнал: {bot_signal}."
    summary = (
        f"{name} ({ticker}) торгуется на {price:.4f}. "
        f"RSI(14)={rsi_val:.0f} ({rsi_sent}), MACD={macd_sent} ({macd_val:.4f}). "
        f"Bollinger: {bb_pos}. "
        f"{signal_text} {pos_text}"
    )
    support = round(bb[0], 4) if bb and bb[0] is not None else 0
    resistance = round(bb[2], 4) if bb and bb[2] is not None else 0
    pivot = round(bb[1], 4) if bb and bb[1] is not None else round(price, 4)
    signals = []
    if rsi_val < 30:
        signals.append(f"RSI перепродан ({rsi_val:.0f}) — сигнал на покупку")
    elif rsi_val > 70:
        signals.append(f"RSI перекуплен ({rsi_val:.0f}) — сигнал на продажу")
    if macd_val > 0:
        signals.append("MACD в положительной зоне — бычий момент")
    elif macd_val < 0:
        signals.append("MACD в отрицательной зоне — медвежий момент")
    else:
        signals.append("MACD в нейтральной зоне — момент отсутствует")
    warnings = []
    if position != "NONE":
        warnings.append(f"Позиция {position} открыта")
    if balance < 10000:
        warnings.append(f"Низкий баланс ({balance:.0f} RUB)")
    if bot_signal == "NEUTRAL":
        recommendation = "wait"
    else:
        recommendation = bot_signal.lower()
    return {
        "sentiment": sentiment,
        "summary": summary,
        "key_levels": {"support": support, "resistance": resistance, "pivot": pivot},
        "signals": signals or ["нет четких сигналов"],
        "warnings": warnings or [],
        "recommendation": recommendation,
    }


# ─── File storage (single overwrite) ──────────────────────────
def today_file() -> Path:
    today = datetime.now().strftime("%Y-%m-%d")
    return BRIEFINGS_DIR / f"briefing_{today}.json"


def write_briefing(entry: dict):
    path = today_file()
    path.parent.mkdir(exist_ok=True)
    entries = []
    if path.exists():
        try:
            entries = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            entries = []
    entries.append(entry)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(entries, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


# ─── Core briefing logic (extracted, receives AsyncServices) ──
async def _do_briefing(svc) -> None:
    instr = await svc.instruments.future_by(id_type=2, class_code="SPBFUT", id=TICKER)
    figi = instr.instrument.figi

    now_utc = datetime.now(timezone.utc)
    if PRELOAD_HOURS > 0:
        from_utc = now_utc - timedelta(hours=PRELOAD_HOURS)
    else:
        session_start = await get_session_start(svc, TICKER)
        if session_start is None:
            from_utc = now_utc - timedelta(hours=48)
        else:
            from_utc = session_start - timedelta(minutes=1)
    closes = []
    candles = []
    async for c in svc.get_all_candles(figi=figi, from_=from_utc, to=now_utc, interval=1):
        closes.append(qfloat(c.close))
        candles.append(
            {
                "time": c.time,
                "open": qfloat(c.open),
                "high": qfloat(c.high),
                "low": qfloat(c.low),
                "close": qfloat(c.close),
                "volume": c.volume or 0,
            }
        )

    if not closes and PRELOAD_HOURS == 0:
        print("[briefing] No candles from session start, fallback to 48h", flush=True)
        from_utc = now_utc - timedelta(hours=48)
        closes = []
        candles = []
        async for c in svc.get_all_candles(figi=figi, from_=from_utc, to=now_utc, interval=1):
            closes.append(qfloat(c.close))
            candles.append(
                {
                    "time": c.time,
                    "open": qfloat(c.open),
                    "high": qfloat(c.high),
                    "low": qfloat(c.low),
                    "close": qfloat(c.close),
                    "volume": c.volume or 0,
                }
            )

    if not closes:
        print("[briefing] No candles, skip.")
        return

    rsi_val = calc_rsi(closes) or 50.0
    atr_val = calc_atr(candles)
    bb = calc_bollinger(closes)
    macd_val, _, _ = calc_macd(closes)
    vwap_val = calc_vwap(candles)
    status = await get_bot_status()

    bot_signal = status.get("current_signal", "NEUTRAL") if status.get("running") else "NEUTRAL"

    price = closes[-1] if closes else 0
    pos = status.get("position", {}).get("side", "NONE")
    bal = status.get("portfolio_balance", 0)
    analysis = build_analysis_template(price, rsi_val, bb, macd_val, atr_val, pos, bal, TICKER, bot_signal)

    msk_tz = timezone(timedelta(hours=3))
    now_msk = datetime.now(msk_tz)
    entry = {
        "ts": now_msk.isoformat(),
        "price": round(price, 4),
        "rsi": round(rsi_val, 1),
        "atr": round(atr_val, 4),
        "bb_lower": round(bb[0], 4) if bb and bb[0] is not None else 0,
        "bb_upper": round(bb[2], 4) if bb and bb[2] is not None else 0,
        "macd": round(macd_val, 4),
        "vwap": round(vwap_val, 4),
        "position": pos,
        "balance": bal,
        "analysis": analysis,
    }
    write_briefing(entry)
    print(f"[briefing] sentiment={analysis.get('sentiment', '?')} price={entry['price']} vwap={entry['vwap']}")


# ─── Main ─────────────────────────────────────────────────────
async def main(client: Optional["AsyncClient"] = None):
    """
    Генерирует брифинг.
    Если client передан (из bot.py) — использует его gRPC-соединение (AsyncServices).
    Если None — создаёт своё (standalone, run_briefing.py).
    """
    try:
        token = os.getenv("TINKOFF_SANDBOX_TOKEN") or os.getenv("TINKOFF_TOKEN")
        if not token:
            print("[briefing] No token, skip.")
            return

        if client is not None:
            await _do_briefing(client)
        else:
            from t_tech.invest import AsyncClient
            from t_tech.invest.constants import INVEST_GRPC_API_SANDBOX, INVEST_GRPC_API

            target = INVEST_GRPC_API_SANDBOX if os.getenv("TINKOFF_SANDBOX_TOKEN") else INVEST_GRPC_API
            async with AsyncClient(token, target=target, app_name="Briefing") as svc:
                await _do_briefing(svc)

    except Exception as e:
        print(f"[briefing] Error: {e}")
        import traceback

        traceback.print_exc()


# ─── Standalone entry point ─────────────────────────────────
if __name__ == "__main__":
    asyncio.run(main())
