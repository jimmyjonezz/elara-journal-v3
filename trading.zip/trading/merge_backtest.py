"""
merge_backtest.py — remove duplicate backtest result files, keep newest per params.

Usage: python merge_backtest.py [--dry-run]

Scans backtest/*.json, groups by (ticker, days, from, to, interval),
keeps the newest file in each group, deletes the rest.
"""

import json
import re
import sys
from pathlib import Path

BACKTEST_DIR = Path(__file__).parent / "backtest"
FILE_PATTERN = re.compile(r"^backtest_result_(\w+)_(\d{8})_(\d{6})\.json$")


def parse_meta(path: Path) -> dict | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return {
        "ticker": data.get("ticker"),
        "days": data.get("days"),
        "from": data.get("from"),
        "to": data.get("to"),
        "interval": data.get("interval"),
    }


def group_key(path: Path) -> tuple | None:
    m = FILE_PATTERN.match(path.name)
    if not m:
        return None
    meta = parse_meta(path)
    if not meta:
        return None
    return (meta["ticker"], meta["days"], meta["from"], meta["to"], meta["interval"])


def merge():
    dry_run = "--dry-run" in sys.argv

    groups: dict[tuple, list[Path]] = {}
    skipped = 0
    for p in sorted(BACKTEST_DIR.glob("*.json")):
        key = group_key(p)
        if key is None:
            skipped += 1
            print(f"  SKIP (unreadable or bad name): {p.name}")
            continue
        groups.setdefault(key, []).append(p)

    total_files = sum(len(v) for v in groups.values())
    total_to_delete = total_files - len(groups)
    total_size_kb = 0

    print(f"{'TICKER':<8} {'DAYS':>4} {'FROM':<12} {'TO':<12} {'INT':>3} {'KEEP':>4} {'DEL':>3}")
    for key in sorted(groups):
        ticker, days, fr, to, interval = key
        files = groups[key]
        if len(files) <= 1:
            print(f"{ticker:<8} {days:>4} {fr:<12} {to:<12} {interval:>3} {len(files):>4} {0:>3}")
            continue
        keep = max(files, key=lambda p: p.stat().st_mtime)
        delete = [p for p in files if p != keep]
        for p in delete:
            total_size_kb += p.stat().st_size / 1024
        print(
            f"{ticker:<8} {days:>4} {fr:<12} {to:<12} {interval:>3} {len(files) - len(delete):>4} {len(delete):>3}  "
            f"keep={keep.name}  delete={','.join(p.name for p in delete)}"
        )
        if not dry_run:
            for p in delete:
                p.unlink()

    total_mb = total_size_kb / 1024
    print(f"\n{'=' * 70}")
    if dry_run:
        print(f"[DRY RUN] Would delete {total_to_delete} files, free ~{total_mb:.2f} MB")
    else:
        print(f"Done: deleted {total_to_delete} files, freed ~{total_mb:.2f} MB")
    print(f"Files before: {total_files} -> after: {len(groups)}  (skipped: {skipped})")


if __name__ == "__main__":
    merge()
