#!/usr/bin/env python3
"""CLI-монитор для торгового бота (rich + pynput)."""

import argparse
import json
import math
import os
import sys
import time
from datetime import datetime
from urllib.request import Request, urlopen

from dotenv import load_dotenv
from rich.align import Align
from rich.box import SIMPLE_HEAD
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

load_dotenv()
API_TOKEN = os.getenv("API_TOKEN", "")

REFRESH_INTERVAL = 2
SPARKLINE_LEN = 60


def _headers():
    h = {"User-Agent": "cli-monitor/1.0"}
    if API_TOKEN:
        h["Authorization"] = f"Bearer {API_TOKEN}"
    return h


def api_get(url):
    req = Request(url, headers=_headers())
    try:
        with urlopen(req, timeout=5) as resp:
            return json.loads(resp.read())
    except Exception:
        return None


def api_post(url):
    req = Request(url, method="POST", headers=_headers())
    try:
        with urlopen(req, timeout=5):
            pass
    except Exception:
        pass


def fmt(n, d=2):
    if n is None:
        return "\u2014"
    return f"{n:.{d}f}"


def fmt_signed(n, d=2):
    if n is None:
        return "\u2014"
    return f"+{n:.{d}f}" if n >= 0 else f"{n:.{d}f}"


def fmt_price(n, ts=1.0):
    if n is None:
        return "\u2014"
    d = max(0, -int(math.log10(ts))) if ts != 1.0 else 2
    return f"{n:.{d}f}"


def sparkline(values, max_width=60):
    if not values:
        return ""
    chars = "\u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588"
    mn, mx = min(values), max(values)
    span = mx - mn or 1
    step = max(1, len(values) // max_width) if len(values) > max_width else 1
    sampled = values[::step][:max_width]
    return "".join(chars[min(int((v - mn) / span * 7), 7)] for v in sampled)


def render_state(data, trades, briefing, signals, price_history):
    layout = Layout()
    layout.split_column(Layout(name="header", size=3), Layout(name="body"), Layout(name="footer", size=1))
    layout["body"].split_row(Layout(name="left"), Layout(name="right"))
    layout["left"].split_column(
        Layout(name="position", size=7),
        Layout(name="indicators", size=7),
        Layout(name="portfolio", size=8),
    )
    layout["right"].split_column(
        Layout(name="briefing", size=8),
        Layout(name="trades", size=10),
        Layout(name="sparkline", size=3),
    )

    if data is None:
        layout["header"].update(Panel("[bold]Waiting for bot server...[/bold]", style="bold"))
        return layout

    ticker = data.get("current_figi", "\u2014")
    mode = data.get("mode", "sandbox")
    uptime = data.get("uptime_sec", 0)
    uptime_str = f"{uptime // 3600}h {(uptime % 3600) // 60}m {uptime % 60}s"
    stream = data.get("stream_connected", False)
    running = data.get("running", False)

    status_icon = "\u25cf"  # bullet
    status_parts = [
        (f" {ticker} ", "bold white on blue"),
        " | ",
        (f"{status_icon} RUNNING" if running else f"{status_icon} STOPPED", "bold green" if running else "bold red"),
        " | ",
        (f"Mode: {mode}", "dim white"),
        " | ",
        (f"Uptime: {uptime_str}", "dim white"),
        " | ",
        ("\u25cf CONNECTED" if stream else "\u25cf DISCONNECTED", "bold cyan" if stream else "bold red"),
    ]
    header_text = Text.assemble(*status_parts)
    layout["header"].update(Panel(header_text, style="bold"))

    pos = data.get("position", {})
    side = pos.get("side", "NONE")
    entry = pos.get("entry_price")
    cur = pos.get("cur_price")
    lot = pos.get("lot", 0)
    ts = data.get("tick_size", 1.0)
    tv = data.get("tick_value", 0.0)

    pnl_unreal = 0.0
    if side not in ("NONE", None) and entry and cur:
        mult = 1 if side == "LONG" else -1
        pnl_unreal = (cur - entry) * mult * (lot or 1) * tv / ts

    side_colors = {"LONG": "bold green", "SHORT": "bold red", "NONE": "bold white"}
    pnl_style = "bold green" if pnl_unreal >= 0 else "bold red"

    t = Table.grid(padding=(0, 2))
    t.add_row("\u0421\u0442\u043e\u0440\u043e\u043d\u0430", Text(side, style=side_colors.get(side, "bold white")))
    t.add_row("\u041b\u043e\u0442\u044b", str(lot) if lot else "\u2014")
    t.add_row("\u0412\u0445\u043e\u0434", fmt_price(entry, ts))
    t.add_row("\u0422\u0435\u043a\u0443\u0449\u0430\u044f", fmt_price(cur, ts))
    t.add_row("P/L", Text(f"{fmt_signed(pnl_unreal)} \u20bd", style=pnl_style))
    layout["left"]["position"].update(Panel(t, title="\u041f\u041e\u0417\u0418\u0426\u0418\u042f", border_style="bright_blue"))

    ema = pos.get("ema")
    ema_s = pos.get("ema_slow")
    rsi = pos.get("rsi")
    adx = pos.get("adx")
    mom = pos.get("momentum")
    vol_m = pos.get("volume_mult")
    signal = data.get("current_signal", "NEUTRAL")
    sig_colors = {"LONG": "green", "SHORT": "red", "NEUTRAL": "yellow"}

    t2 = Table.grid(padding=(0, 2))
    t2.add_row("EMA(9)", fmt(ema, 2) if ema else "\u2014", "EMA(21)", fmt(ema_s, 2) if ema_s else "\u2014")
    t2.add_row("RSI(14)", fmt(rsi, 1) if rsi else "\u2014", "ADX", fmt(adx, 1) if adx else "\u2014")
    t2.add_row("Momentum", fmt(mom, 3) if mom else "\u2014", "Vol/x", fmt(vol_m, 2) if vol_m else "\u2014")
    t2.add_row(
        "\u0421\u0438\u0433\u043d\u0430\u043b",
        Text(signal, style=sig_colors.get(signal, "bold yellow")),
        "Streak",
        str(data.get("signal_streak", 0)),
    )
    layout["left"]["indicators"].update(Panel(t2, title="\u0418\u041d\u0414\u0418\u041a\u0410\u0422\u041e\u0420\u042b", border_style="bright_magenta"))

    bal = data.get("portfolio_balance", 0)
    blk = data.get("portfolio_blocked", 0)
    avail = bal - blk
    dpnl = data.get("daily_pnl", 0)
    tpnl = data.get("total_pnl", 0)
    trades_cnt = data.get("trade_count", 0)
    wr = data.get("winrate", 0)

    t3 = Table.grid(padding=(0, 2))
    t3.add_row("\u0411\u0430\u043b\u0430\u043d\u0441", f"{fmt(bal, 0)} \u20bd", "\u0417\u0430\u0431\u043b\u043e\u043a.", f"{fmt(blk, 0)} \u20bd")
    t3.add_row("\u0414\u043e\u0441\u0442\u0443\u043f\u043d\u043e", f"{fmt(avail, 0)} \u20bd", "P/L \u0434\u0435\u043d\u044c", Text(f"{fmt_signed(dpnl, 0)} \u20bd", style="green" if dpnl >= 0 else "red"))
    t3.add_row("P/L \u0432\u0441\u0435\u0433\u043e", Text(f"{fmt_signed(tpnl, 0)} \u20bd", style="green" if tpnl >= 0 else "red"), "\u0421\u0434\u0435\u043b\u043e\u043a", str(trades_cnt))
    t3.add_row("\u0412\u0438\u043d\u0440\u0435\u0439\u0442", f"{fmt(wr, 1)}%", "", "")
    layout["left"]["portfolio"].update(Panel(t3, title="\u041f\u041e\u0420\u0422\u0424\u0415\u041b\u042c", border_style="bright_green"))

    if briefing:
        b = briefing.get("analysis") or briefing.get("briefing") or briefing
        rec = (b.get("recommendation") or "WAIT").upper()
        rsi_val = b.get("rsi") or briefing.get("rsi") or "\u2014"
        vwap_val = b.get("vwap") or briefing.get("vwap") or "\u2014"
        supp_val = b.get("support") or briefing.get("support") or "\u2014"
        res_val = b.get("resistance") or briefing.get("resistance") or "\u2014"
        pivot_val = b.get("pivot") or briefing.get("pivot") or "\u2014"
        rec_colors = {"LONG": "bold green", "SHORT": "bold red", "WAIT": "bold yellow"}

        t4 = Table.grid(padding=(0, 2))
        t4.add_row("\u0420\u0435\u043a\u043e\u043c\u0435\u043d\u0434\u0430\u0446\u0438\u044f", Text(rec, style=rec_colors.get(rec, "bold yellow")))
        t4.add_row("RSI(14)", str(rsi_val) if rsi_val != "\u2014" else "\u2014")
        t4.add_row("VWAP", fmt_price(vwap_val, ts) if isinstance(vwap_val, (int, float)) else str(vwap_val))
        t4.add_row("\u041f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0430", fmt_price(supp_val, ts) if isinstance(supp_val, (int, float)) else str(supp_val))
        t4.add_row("\u0421\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b.", fmt_price(res_val, ts) if isinstance(res_val, (int, float)) else str(res_val))
        t4.add_row("\u041f\u0438\u0432\u043e\u0442", fmt_price(pivot_val, ts) if isinstance(pivot_val, (int, float)) else str(pivot_val))
        layout["right"]["briefing"].update(Panel(t4, title="\u0411\u0420\u0418\u0424\u0418\u041d\u0413", border_style="bright_yellow"))
    else:
        layout["right"]["briefing"].update(Panel("\u2014", title="\u0411\u0420\u0418\u0424\u0418\u041d\u0413", border_style="bright_yellow"))

    if trades and len(trades) > 0:
        t5 = Table(box=SIMPLE_HEAD, header_style="bold")
        t5.add_column("\u0412\u0440\u0435\u043c\u044f", width=5)
        t5.add_column("\u0422\u0438\u043f", width=4)
        t5.add_column("\u0426\u0435\u043d\u0430", width=8)
        t5.add_column("P/L", width=8)
        for tr in trades[:7]:
            direction = (tr.get("direction") or "").upper() if tr.get("direction") else ""
            dt = tr.get("time") or ""
            m = dt.split(" ")
            time_str = m[-1][:5] if len(m) > 1 else dt[:5]
            price = tr.get("price")
            pnl = tr.get("pnl", 0)
            action = (tr.get("action") or direction)[:4].upper()
            side_color = "green" if action in ("LONG", "BUY") else "red"
            pnl_color = "green" if (pnl or 0) >= 0 else "red"
            t5.add_row(
                time_str,
                Text(action, style=side_color),
                fmt_price(price, ts) if price else "\u2014",
                Text(f"{fmt_signed(pnl, 0)} \u20bd" if pnl else "\u2014", style=pnl_color),
            )
        layout["right"]["trades"].update(Panel(t5, title="\u0421\u0414\u0415\u041b\u041a\u0418", border_style="bright_cyan"))
    else:
        layout["right"]["trades"].update(Panel("\u041d\u0435\u0442 \u0441\u0434\u0435\u043b\u043e\u043a", title="\u0421\u0414\u0415\u041b\u041a\u0418", border_style="bright_cyan"))

    if price_history:
        sp = sparkline(price_history)
        price_text = Text(sp, style="bold cyan")
        layout["right"]["sparkline"].update(
            Panel(Align.center(price_text), title="\u0426\u0415\u041d\u0410 (\u043f\u043e\u0441\u043b. 60)", border_style="bright_white")
        )
    else:
        layout["right"]["sparkline"].update(Panel("\u2014", title="\u0426\u0415\u041d\u0410", border_style="bright_white"))

    now_str = datetime.now().strftime("%H:%M:%S")
    footer_parts = [
        (f" \u041e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u043e: {now_str}", "dim white"),
        ("  |  ", "dim white"),
        ("Hotkeys: ", "dim white"),
        ("[s]", "bold yellow"),
        ("tart ", "dim white"),
        ("[t]", "bold yellow"),
        ("op ", "dim white"),
        ("[l]", "bold yellow"),
        ("ong ", "dim white"),
        ("[S]", "bold yellow"),
        ("hort ", "dim white"),
        ("[c]", "bold yellow"),
        ("lose ", "dim white"),
        ("[q]", "bold red"),
        ("uit", "dim white"),
    ]
    footer_text = Text.assemble(*footer_parts)
    layout["footer"].update(Panel(footer_text, style="dim"))

    return layout


def main():
    parser = argparse.ArgumentParser(description="CLI \u043c\u043e\u043d\u0438\u0442\u043e\u0440 \u0442\u043e\u0440\u0433\u043e\u0432\u043e\u0433\u043e \u0431\u043e\u0442\u0430")
    parser.add_argument("--port", type=int, default=5000, help="Bot API port")
    args = parser.parse_args()

    base_url = f"http://localhost:{args.port}"
    price_history = []

    hotkey_enabled = False
    try:
        from pynput import keyboard

        hotkey_enabled = True
    except ImportError:
        print("[CLI] pynput not installed \u2014 hotkeys disabled. Install: pip install pynput", file=sys.stderr)

    def on_press(key):
        try:
            k = key.char
        except AttributeError:
            return
        if k == "q":
            os._exit(0)
        elif k == "s":
            api_post(f"{base_url}/api/bot/start")
        elif k == "t":
            api_post(f"{base_url}/api/bot/stop")
        elif k == "l":
            api_post(f"{base_url}/api/bot/open")
        elif k == "S":
            api_post(f"{base_url}/api/bot/open?side=SHORT")
        elif k == "c":
            api_post(f"{base_url}/api/bot/close")

    if hotkey_enabled:
        listener = keyboard.Listener(on_press=on_press)
        listener.daemon = True
        listener.start()

    with Live(refresh_per_second=1, screen=True) as live:
        while True:
            data = api_get(f"{base_url}/api/status")
            trades = api_get(f"{base_url}/api/trades")
            briefing = api_get(f"{base_url}/api/briefing")
            signals = api_get(f"{base_url}/api/signals")

            if data:
                pos = data.get("position", {})
                cur = pos.get("cur_price")
                if cur:
                    price_history.append(cur)
                    if len(price_history) > SPARKLINE_LEN * 2:
                        price_history = price_history[-SPARKLINE_LEN:]

            layout = render_state(data, trades, briefing, signals, price_history)
            live.update(layout)
            time.sleep(REFRESH_INTERVAL)


if __name__ == "__main__":
    main()
