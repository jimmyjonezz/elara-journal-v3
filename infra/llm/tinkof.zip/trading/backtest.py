"""
backtest.py — прогон стратегии CCM6 на исторических данных за N дней.
Использует те же индикаторы, что и bot.py.
"""
import sys, os, json, asyncio, math
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) or ".")
from dotenv import load_dotenv
load_dotenv()

from configbot import (
    TICKER, SANDBOX,
    EMA_FAST, EMA_SLOW, RSI_PERIOD, RSI_OVERBOUGHT, RSI_OVERSOLD,
    VOLUME_MULTIPLIER, MOMENTUM_PERIOD,
    STOP_LOSS_PCT, TAKE_PROFIT_PCT,
    TRAILING_ACTIVATE, TRAILING_DISTANCE, TIME_FILTER_HOUR,
    MOMENTUM_MIN, VOLUME_ABS_MIN, ADX_MIN, RSI_OVERBOUGHT_FILTER,
)

from bot import qfloat, calc_ema, calc_rsi, calc_adx, calc_momentum, calc_volume_avg
from t_tech.invest import AsyncClient, MoneyValue
from t_tech.invest.constants import INVEST_GRPC_API_SANDBOX

DAYS = 7

@dataclass
class Trade:
    side: str
    entry_time: datetime
    entry_price: float
    exit_time: datetime = None
    exit_price: float = None
    reason: str = ''
    pnl: float = 0.0

@dataclass
class BacktestState:
    side: str = 'NONE'
    entry_price: float = 0.0
    entry_time: datetime = None
    entry_bar: int = 0
    peak_price: float = 0.0
    trailing_active: bool = False
    trades: list = field(default_factory=list)
    equity: float = 20000.0
    peak_equity: float = 20000.0

    def reset(self):
        self.side = 'NONE'
        self.entry_price = 0.0
        self.entry_time = None
        self.entry_bar = 0
        self.peak_price = 0.0
        self.trailing_active = False

def calc_bollinger(closes, period=20, mult=2.0):
    if len(closes) < period:
        return None, None, None
    import statistics
    mean = statistics.mean(closes[-period:])
    std = statistics.stdev(closes[-period:])
    return mean - mult * std, mean, mean + mult * std

def pnl_pct(side, entry, cur):
    if entry <= 0:
        return 0.0
    return ((cur - entry) / entry * 100) if side == 'LONG' else ((entry - cur) / entry * 100)

async def run():
    token = os.getenv("TINKOFF_SANDBOX_TOKEN") or os.getenv("TINKOFF_TOKEN")
    if not token:
        print("ERROR: no token")
        return

    target = INVEST_GRPC_API_SANDBOX if SANDBOX else None
    async with AsyncClient(token, target=target, app_name="Backtest") as client:
        instr = await client.instruments.future_by(id_type=2, class_code="SPBFUT", id=TICKER)
        figi = instr.instrument.figi
        print(f"{TICKER} -> {figi}")

        now = datetime.now(timezone.utc)
        from_ = now - timedelta(days=DAYS)
        print(f"Loading {DAYS} days ({from_.date()} to {now.date()})...")

        candles = []
        async for c in client.get_all_candles(figi=figi, from_=from_, to=now, interval=1):
            candles.append(c)
        print(f"Loaded {len(candles)} candles")

        if not candles:
            print("No candles")
            return

        bt = BacktestState()
        cooldown_until = from_

        for i, c in enumerate(candles):
            price = qfloat(c.close)
            ts = c.time

            if i < EMA_SLOW:
                continue

            closes = [qfloat(x.close) for x in candles[:i+1]]
            highs = [qfloat(x.high) for x in candles[:i+1]]
            lows = [qfloat(x.low) for x in candles[:i+1]]
            volumes = [x.volume for x in candles[:i+1]]

            ema_f = calc_ema(closes, EMA_FAST)
            ema_s = calc_ema(closes, EMA_SLOW)
            rsi = calc_rsi(closes, RSI_PERIOD)
            adx = calc_adx(highs, lows, closes, 14)
            mom = calc_momentum(closes, MOMENTUM_PERIOD)
            vol_avg = calc_volume_avg(volumes, 20)
            vol = volumes[-1]

            bb_l, bb_m, bb_u = calc_bollinger(closes)

            msk = ts + timedelta(hours=3)

            # ── Exit logic ──
            if bt.side != 'NONE':
                pp = pnl_pct(bt.side, bt.entry_price, price)

                # Trailing
                if pp >= TRAILING_ACTIVATE and not bt.trailing_active:
                    bt.trailing_active = True
                    bt.peak_price = price

                if bt.trailing_active:
                    if bt.side == 'LONG':
                        if price > bt.peak_price:
                            bt.peak_price = price
                        trail_level = bt.peak_price * (1 - TRAILING_DISTANCE / 100)
                        if price <= trail_level:
                            t = Trade(bt.side, bt.entry_time, bt.entry_price, ts, price, 'TRAIL', 0.0)
                            t.pnl = round((price - bt.entry_price) * 10, 2)
                            bt.trades.append(t)
                            bt.equity += t.pnl
                            bt.peak_equity = max(bt.peak_equity, bt.equity)
                            bt.reset()
                            continue
                    else:
                        if price < bt.peak_price:
                            bt.peak_price = price
                        trail_level = bt.peak_price * (1 + TRAILING_DISTANCE / 100)
                        if price >= trail_level:
                            t = Trade(bt.side, bt.entry_time, bt.entry_price, ts, price, 'TRAIL', 0.0)
                            t.pnl = round((bt.entry_price - price) * 10, 2)
                            bt.trades.append(t)
                            bt.equity += t.pnl
                            bt.peak_equity = max(bt.peak_equity, bt.equity)
                            bt.reset()
                            continue

                # Stop-Loss
                if pp <= -STOP_LOSS_PCT:
                    side = bt.side
                    ep = bt.entry_price
                    t = Trade(side, bt.entry_time, ep, ts, price, 'SL', 0.0)
                    t.pnl = round((price - ep) * 10, 2) if side == 'LONG' else round((ep - price) * 10, 2)
                    bt.trades.append(t)
                    bt.equity += t.pnl
                    bt.peak_equity = max(bt.peak_equity, bt.equity)
                    bt.reset()
                    continue

                # Take-Profit
                if pp >= TAKE_PROFIT_PCT:
                    side = bt.side
                    ep = bt.entry_price
                    t = Trade(side, bt.entry_time, ep, ts, price, 'TP', 0.0)
                    t.pnl = round((price - ep) * 10, 2) if side == 'LONG' else round((ep - price) * 10, 2)
                    bt.trades.append(t)
                    bt.equity += t.pnl
                    bt.peak_equity = max(bt.peak_equity, bt.equity)
                    bt.reset()
                    continue

            # ── Entry logic ──
            if bt.side == 'NONE' and ts >= cooldown_until:
                if None in (ema_f, ema_s, rsi, vol_avg):
                    continue
                if msk.hour >= TIME_FILTER_HOUR:
                    continue

                trend_up = ema_f > ema_s
                vol_ok = vol >= vol_avg * VOLUME_MULTIPLIER and vol >= VOLUME_ABS_MIN
                adx_ok = adx is None or adx >= ADX_MIN
                mom_ok = mom is None or abs(mom) >= MOMENTUM_MIN

                if trend_up and vol_ok and adx_ok and mom_ok and rsi <= RSI_OVERBOUGHT_FILTER:
                    bt.side = 'LONG'
                    bt.entry_price = price
                    bt.entry_time = ts
                    bt.entry_bar = i
                    bt.peak_price = price
                    cooldown_until = ts + timedelta(minutes=30)

                elif not trend_up and vol_ok and adx_ok and mom_ok and RSI_OVERSOLD <= rsi <= 55:
                    bt.side = 'SHORT'
                    bt.entry_price = price
                    bt.entry_time = ts
                    bt.entry_bar = i
                    bt.peak_price = price
                    cooldown_until = ts + timedelta(minutes=30)

        # Close any open position at end
        if bt.side != 'NONE':
            price = qfloat(candles[-1].close)
            t = Trade(bt.side, bt.entry_time, bt.entry_price, candles[-1].time, price, 'FORCE_CLOSE', 0.0)
            t.pnl = round((price - bt.entry_price) * 10, 2) if bt.side == 'LONG' else round((bt.entry_price - price) * 10, 2)
            bt.trades.append(t)
            bt.equity += t.pnl
            bt.peak_equity = max(bt.peak_equity, bt.equity)
            bt.reset()

        # ── Results ──
        closed = bt.trades
        wins = [t for t in closed if t.pnl > 0]
        losses = [t for t in closed if t.pnl < 0]
        total_pnl = sum(t.pnl for t in closed)
        dd = max(0, bt.peak_equity - min(bt.equity, bt.peak_equity)) if closed else 0

        print(f"\n{'='*55}")
        print(f"BACKTEST RESULTS — {DAYS} days")
        print(f"{'='*55}")
        print(f"Period:      {candles[0].time.date()} to {candles[-1].time.date()}")
        print(f"Candles:     {len(candles)}")
        print(f"Trades:      {len(closed)}")
        print(f"Wins:        {len(wins)}")
        print(f"Losses:      {len(losses)}")
        wr = round(len(wins) / len(closed) * 100, 1) if closed else 0
        print(f"WinRate:     {wr}%")
        print(f"Total P/L:   {total_pnl:+.2f} RUB")
        print(f"Avg P/L:     {round(total_pnl / len(closed), 2) if closed else 0:+.2f} RUB")
        print(f"Best:        {max((t.pnl for t in closed), default=0):+.2f} RUB")
        print(f"Worst:       {min((t.pnl for t in closed), default=0):+.2f} RUB")
        print(f"Start:       20000.00 RUB")
        print(f"End:         {bt.equity:.2f} RUB")
        print(f"Return:      {((bt.equity - 20000) / 20000 * 100):+.2f}%")
        print(f"Drawdown:    {dd:.2f} RUB")
        print(f"{'='*55}\n")

        # Top 10 trades
        print("Top trades:")
        for t in sorted(closed, key=lambda x: abs(x.pnl), reverse=True)[:10]:
            print(f"  {t.side:5s} | {t.entry_time.strftime('%m-%d %H:%M')} -> {t.exit_time.strftime('%m-%d %H:%M') if t.exit_time else '?'} | "
                  f"entry={t.entry_price:.2f} exit={t.exit_price:.2f} | {t.reason:10s} | P/L={t.pnl:+.2f}")

if __name__ == "__main__":
    asyncio.run(run())
