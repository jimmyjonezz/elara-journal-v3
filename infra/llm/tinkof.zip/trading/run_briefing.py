#!/usr/bin/env python3
"""Точка входа брифинга — загружает env, запускает briefing.main().
   Можно также напрямую: python -c "import asyncio; from briefing import main; asyncio.run(main())"
"""
import os, sys
from pathlib import Path

for env_file in [Path.home() / ".hermes" / ".env", Path(__file__).parent / ".env"]:
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())

sys.path.insert(0, str(Path(__file__).parent))
from briefing import main
import asyncio
asyncio.run(main())
