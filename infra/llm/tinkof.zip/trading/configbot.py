"""
Конфигурация фьючерсного бота (CCM6)
=== ТОКЕНЫ см. .env ===
"""
from dotenv import load_dotenv
import os

load_dotenv()

# === РЕЖИМ ===
SANDBOX = True           # True = песочница, False = реальный счёт
AUTO_PAYIN = False       # Автопополнение песочницы при старте (RUB)
ACCOUNT_ID = ""           # ID счёта (пусто = автосоздание)

# === DEBUG ===
DEBUG = True              # Детальный вывод индикаторов

# === ИНСТРУМЕНТ ===
TICKER = "CCM6"          # Тикер фьючерса (MOEX Clearing)

# === ИНТЕРВАЛ СВЕЧЕЙ ===
CANDLE_INTERVAL = "5m"    # 5-минутные свечи

# === СТРАТЕГИЯ ===
EMA_FAST = 9             # Быстрая EMA
EMA_SLOW = 21            # Медленная EMA
RSI_PERIOD = 14          # Период RSI
RSI_OVERBOUGHT = 70      # RSI перекупленность
RSI_OVERSOLD = 30        # RSI перепроданность
VOLUME_MULTIPLIER = 1.2  # Множитель объёма для spike
MOMENTUM_PERIOD = 6      # Momentum (в барах 5-мин = ~30 мин)

# === ФИЛЬТРЫ ВХОДА ===
MOMENTUM_MIN = 0.5       # Минимум momentum (%) для входа
VOLUME_ABS_MIN = 60      # Мин. абсолютный объём (контрактов)
ADX_MIN = 22             # Мин. ADX (сила тренда)
ENTRY_COOLDOWN = 1800    # Пауза между входами (сек, 30 мин)
RSI_OVERBOUGHT_FILTER = 55  # Запрет LONG если RSI выше этого

# === РИСК-МЕНЕДЖМЕНТ ===
RISK_PERCENT = 1.0       # Риск на сделку (% от депозита)
STOP_LOSS_PCT = 0.8      # Стоп-лосс (%)
TAKE_PROFIT_PCT = 1.5    # Тейк-профит (%)

# === TRAILING STOP ===
TRAILING_ACTIVATE = 0.8   # Активация trailing при росте (%)
TRAILING_DISTANCE = 0.4   # Дистанция trailing (% от пика)

# === СЕРВЕР ===
SERVER_PORT = 5000        # Порт дашборда

# === ВРЕМЯ ===
MIN_HOLD_TIME = 600      # Мин. удержание до выхода по RSI (сек)
TIME_FILTER_HOUR = 19    # Запрет входа после этого часа (МСК)
PRELOAD_HOURS = 6        # Сколько часов истории загружать (6ч ~= 360 свечей 1мин)