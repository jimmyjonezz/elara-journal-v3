import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["BOT_TICKER"] = "CCM6"

import asyncio
import time
import pytest
from apiclient import RateLimiter, is_definitive


class TestRateLimiter:
    async def test_acquire_returns_immediately(self):
        lim = RateLimiter(10, 60)
        t0 = time.monotonic()
        await lim.acquire()
        assert time.monotonic() - t0 < 0.1

    async def test_acquire_blocks_when_exhausted(self):
        lim = RateLimiter(2, 2)
        await lim.acquire()
        await lim.acquire()
        t0 = time.monotonic()
        await lim.acquire()
        elapsed = time.monotonic() - t0
        assert elapsed >= 0.5

    async def test_tokens_capped_at_max(self):
        lim = RateLimiter(5, 1)
        await lim.acquire()
        await asyncio.sleep(2)
        await lim.acquire()
        assert lim.tokens <= lim.max_calls + 1e-9

    async def test_zero_max_calls(self):
        lim = RateLimiter(0, 60)
        with pytest.raises(ZeroDivisionError):
            await lim.acquire()

    async def test_concurrent_acquire(self):
        lim = RateLimiter(1, 0.5)

        async def task():
            await lim.acquire()

        t0 = time.monotonic()
        t1 = asyncio.create_task(task())
        t2 = asyncio.create_task(task())
        await asyncio.gather(t1, t2)
        elapsed = time.monotonic() - t0
        assert elapsed >= 0.0

    async def test_very_small_period(self):
        lim = RateLimiter(100, 0.001)
        t0 = time.monotonic()
        await lim.acquire()
        assert time.monotonic() - t0 < 0.1

    async def test_refill_over_time(self):
        lim = RateLimiter(1, 0.5)
        await lim.acquire()
        assert lim.tokens == 0
        await asyncio.sleep(0.6)
        await lim.acquire()
        assert lim.tokens < 1.0

    async def test_partial_refill(self):
        lim = RateLimiter(60, 60)
        await lim.acquire()
        assert lim.tokens == 59.0
        await asyncio.sleep(0.5)
        await lim.acquire()
        assert 57.0 <= lim.tokens <= 59.0

    async def test_low_rate_then_wait(self):
        lim = RateLimiter(1, 10)
        await lim.acquire()
        t0 = time.monotonic()
        await lim.acquire()
        assert time.monotonic() - t0 >= 9.0


from t_tech.invest.exceptions import AioRequestError


class _FakeAioError(AioRequestError):
    def __init__(self, details="", code=None):
        self.details = details
        self.code = code


class TestIsDefinitive:
    def test_non_aio_request_error(self):
        assert is_definitive(ValueError("test")) is False
        assert is_definitive(RuntimeError("test")) is False
        assert is_definitive(Exception()) is False
        assert is_definitive(None) is False

    def test_no_details(self):
        assert is_definitive(_FakeAioError(details=None)) is False

    def test_empty_details(self):
        assert is_definitive(_FakeAioError(details="")) is False

    def test_30079_exact(self):
        assert is_definitive(_FakeAioError(details="30079")) is True

    def test_30079_substring(self):
        assert is_definitive(_FakeAioError(details="error 30079: market closed")) is True

    def test_not_available_for_trading(self):
        assert is_definitive(_FakeAioError(details="Not available for trading")) is True

    def test_30042_exact(self):
        assert is_definitive(_FakeAioError(details="30042")) is True

    def test_instrument_not_found(self):
        assert is_definitive(_FakeAioError(details="Instrument not found")) is True

    def test_case_insensitive(self):
        assert is_definitive(_FakeAioError(details="NOT AVAILABLE FOR TRADING")) is True

    def test_partial_number_no_match(self):
        assert is_definitive(_FakeAioError(details="50000: some other error")) is False

    def test_30079_30042_both(self):
        assert is_definitive(_FakeAioError(details="30079 and 30042")) is True

    def test_unknown_error(self):
        assert is_definitive(_FakeAioError(details="50000: unknown error")) is False

    def test_with_real_import(self):
        e = AioRequestError(code=None, details="30079: market closed", metadata=None)
        assert is_definitive(e) is True

    def test_real_error_non_definitive(self):
        e = AioRequestError(code=None, details="rate limit exceeded", metadata=None)
        assert is_definitive(e) is False

    def test_unicode_in_details(self):
        assert is_definitive(_FakeAioError(details="ошибка 30079")) is True

    def test_details_is_zero(self):
        assert is_definitive(_FakeAioError(details=0)) is False
