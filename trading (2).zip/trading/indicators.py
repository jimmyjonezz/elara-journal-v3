"""indicators.py — Pure-math indicator functions. No config imports."""


def calc_ema(values, period):
    if len(values) < period:
        return None
    k = 2.0 / (period + 1)
    ema = sum(values[:period]) / period
    for v in values[period:]:
        ema = v * k + ema * (1 - k)
    return ema


def calc_rsi(closes, period=14):
    if len(closes) < period + 1:
        return None
    deltas = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gains = [d if d > 0 else 0 for d in deltas]
    losses = [-d if d < 0 else 0 for d in deltas]
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for i in range(period, len(deltas)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss == 0:
        return 100.0
    return 100.0 - (100.0 / (1.0 + avg_gain / avg_loss))


def _calc_di(highs, lows, closes, period=14):
    """Returns (adx, plus_di_last, minus_di_last) or (None, None, None)."""
    if len(closes) < period * 2 + 1:
        return None, None, None
    trs, plus_dms, minus_dms = [], [], []
    for i in range(1, len(closes)):
        tr = max(highs[i] - lows[i], highs[i] - closes[i - 1], closes[i - 1] - lows[i])
        plus = highs[i] - highs[i - 1]
        minus = lows[i - 1] - lows[i]
        trs.append(tr)
        plus_dms.append(plus if plus > minus and plus > 0 else 0)
        minus_dms.append(minus if minus > plus and minus > 0 else 0)

    def smooth(data, p):
        s = sum(data[:p]) / p
        result = [s]
        for i in range(p, len(data)):
            s = (s * (p - 1) + data[i]) / p
            result.append(s)
        return result

    tr_s, plus_s, minus_s = smooth(trs, period), smooth(plus_dms, period), smooth(minus_dms, period)
    plus_di = [100 * p / t if t > 0 else 0 for p, t in zip(plus_s, tr_s)]
    minus_di = [100 * m / t if t > 0 else 0 for m, t in zip(minus_s, tr_s)]
    dx = [
        abs(plus_di[i] - minus_di[i]) / (plus_di[i] + minus_di[i]) * 100 if (plus_di[i] + minus_di[i]) > 0 else 0
        for i in range(len(plus_di))
    ]
    if len(dx) < period:
        return None, None, None
    adx = sum(dx[:period]) / period
    for i in range(period, len(dx)):
        adx = (adx * (period - 1) + dx[i]) / period
    return adx, plus_di[-1], minus_di[-1]


def calc_adx(highs, lows, closes, period=14):
    adx, _, _ = _calc_di(highs, lows, closes, period)
    return adx


def calc_plus_di(highs, lows, closes, period=14):
    _, pdi, _ = _calc_di(highs, lows, closes, period)
    return pdi


def calc_minus_di(highs, lows, closes, period=14):
    _, _, mdi = _calc_di(highs, lows, closes, period)
    return mdi


def calc_momentum(closes, period=10):
    if len(closes) < period + 1:
        return None
    prev = closes[-period - 1]
    if prev == 0:
        return None
    return (closes[-1] - prev) / prev * 100


def calc_volume_avg(volumes, period=20):
    if not volumes:
        return 0
    return sum(volumes[-min(period, len(volumes)):]) / min(period, len(volumes))


def calc_bollinger(closes, period=20, mult=2.0):
    if len(closes) < period:
        return None, None, None
    import statistics

    mean = statistics.mean(closes[-period:])
    std = statistics.stdev(closes[-period:])
    return mean - mult * std, mean, mean + mult * std


def calc_percentile(values, percentile):
    if not values:
        return None
    s = sorted(values)
    idx = int(len(s) * percentile / 100)
    idx = max(0, min(idx, len(s) - 1))
    return s[idx]
