"""
Фьючерсный моментум-бот (gRPC через SDK t-tech-investments)
"""

import sys
import os
import re
import json
import asyncio
from datetime import datetime, timezone, timedelta
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) or ".")
sys.stdout.reconfigure(encoding="utf-8")

from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

from configbot import (
    SANDBOX,
    ACCOUNT_ID,
    TICKER,
    DEBUG,
    EMA_FAST,
    EMA_SLOW,
    RSI_PERIOD,
    RSI_OVERSOLD,
    VOLUME_MULTIPLIER,
    MOMENTUM_PERIOD,
    STOP_LOSS_PCT,
    TAKE_PROFIT_PCT,
    TRAILING_ACTIVATE,
    TRAILING_DISTANCE,
    TIME_FILTER_HOUR,
    PRELOAD_HOURS,
    MOMENTUM_MIN,
    VOLUME_ABS_MIN,
    ADX_MIN,
    MAX_SPREAD_PCT,
    MIN_BETWEEN_SL,
    MIN_SIGNAL_STREAK,
    MIN_COOLDOWN_SEC,
    RSI_OVERBOUGHT_FILTER,
    PERCENTILE_DAYS,
    PERCENTILE_FILTER,
    COMMISSION_PCT,
    BB_FILTER,
    BB_TOLERANCE,
    EMA_MARGIN_PCT,
    MAX_CONSECUTIVE_LOSSES,
    CIRCUIT_BREAKER_COOLDOWN,
    LOT,
    LEVERAGE_FACTOR,
    INITIAL_EQUITY,
    DI_HARD_BLOCK,
    DI_THRESHOLD,
)
from shared import (
    state,
    Position,
    get_lifecycle_event,
    qfloat,
    log_trade,
    log_candle,
    load_candles_from_log,
    get_session_start,
)
from apiclient import post_order_with_retry, margin_lim
from indicators import (
    calc_ema,
    calc_rsi,
    calc_adx,
    calc_plus_di,
    calc_minus_di,
    calc_momentum,
    calc_volume_avg,
    calc_bollinger,
    calc_percentile,
)


_briefing_running = False


async def _safe_briefing():
    global _briefing_running
    if _briefing_running:
        return
    _briefing_running = True
    try:
        await _briefing.main()
    finally:
        _briefing_running = False


def _circuit_check(pnl: float, now_utc):
    """Записать сделку + активировать circuit breaker при N убытков подряд."""
    state.record_trade(pnl)
    asyncio.create_task(_safe_briefing())
    if state.consecutive_losses >= MAX_CONSECUTIVE_LOSSES:
        state.circuit_breaker_until = now_utc + timedelta(seconds=CIRCUIT_BREAKER_COOLDOWN)
        state.circuit_breaker = True


async def close_via_sandbox_or_retry(
    client, figi, uid, quantity, direction, account_id, order_type, price=0, contract_multiplier=0
):
    """Close with sandbox_pay_in before SHORT-close (BUY) in sandbox, then post_order_with_retry."""
    if SANDBOX and direction == OrderDirection.ORDER_DIRECTION_BUY:
        extra = round(price * quantity * contract_multiplier * 1.1)
        if extra > 0:
            try:
                await client.sandbox.sandbox_pay_in(
                    account_id=account_id,
                    amount=MoneyValue(currency="rub", units=extra, nano=0),
                )
                print(f"  >> Sandbox pay-in {extra} RUB for SHORT close", flush=True)
                await asyncio.sleep(1)
            except Exception as e:
                print(f"  >> Sandbox pay-in error: {e}", flush=True)
    try:
        await post_order_with_retry(
            client,
            figi=figi,
            uid=uid,
            quantity=quantity,
            direction=direction,
            account_id=account_id,
            order_type=order_type,
        )
    except Exception as e:
        d = str(e).lower()
        if "30079" in d or "not available for trading" in d:
            print("  >> Market closed (30079). Deferred until next market open.", flush=True)
            raise RuntimeError("30079") from e
        raise


from t_tech.invest import (
    AsyncClient,
    CandleInstrument,
    InfoInstrument,
    SubscriptionInterval,
    OrderDirection,
    OrderType,
    MoneyValue,
    SecurityTradingStatus,
)
from t_tech.invest.market_data_stream.async_market_data_stream_manager import (
    AsyncMarketDataStreamManager,
)
from t_tech.invest.constants import INVEST_GRPC_API, INVEST_GRPC_API_SANDBOX

import briefing as _briefing

# ── helpers ───────────────────────────────────────────────────


def cell_mk(c):
    return (qfloat(c.open), qfloat(c.high), qfloat(c.low), qfloat(c.close))


def price_to_float(m) -> float:
    return qfloat(m)


SDK_TARGET = INVEST_GRPC_API_SANDBOX if SANDBOX else INVEST_GRPC_API

# ── log dir ───────────────────────────────────────────────────

LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
os.makedirs(LOG_DIR, exist_ok=True)


def load_stats_from_logs() -> dict:
    today_prefix = datetime.now().strftime("%d%m%Y")
    total_c = total_w = total_l = 0
    total_p = 0.0
    daily_p = 0.0
    if not os.path.isdir(LOG_DIR):
        return {"trade_count": 0, "win_count": 0, "loss_count": 0, "daily_pnl": 0.0, "total_pnl": 0.0, "winrate": 0.0}
    for fname in sorted(os.listdir(LOG_DIR)):
        if not (fname.startswith("trades_") and fname.endswith(".log")):
            continue
        is_today = fname == f"trades_{today_prefix}.log"
        with open(os.path.join(LOG_DIR, fname), encoding="utf-8") as f:
            for line in f:
                m = re.search(r"P/L:\s*([+-]?[\d.]+)", line)
                if not m:
                    continue
                v = float(m.group(1))
                total_p += v
                total_c += 1
                total_w += v > 0
                total_l += v < 0
                if is_today:
                    daily_p += v
    wr = round(total_w / total_c * 100, 1) if total_c else 0.0
    return {
        "trade_count": total_c,
        "win_count": total_w,
        "loss_count": total_l,
        "total_pnl": round(total_p, 2),
        "daily_pnl": round(daily_p, 2),
        "winrate": wr,
    }


def log_portfolio():
    """Записать состояние портфеля в JSONL (одна строка = JSON)."""
    try:
        now = datetime.now()
        entry = {
            "ts": now.strftime("%Y-%m-%dT%H:%M:%S"),
            "balance": round(state.portfolio_balance, 2),
            "blocked": round(state.portfolio_blocked, 2),
            "side": state.position.side,
            "entry_price": round(state.position.entry_price, 4) if state.position.entry_price else 0,
            "lot": state.position.lot,
            "price": round(state.current_price, 4),
            "daily_pnl": round(state.daily_pnl, 2),
            "total_pnl": round(state.total_pnl, 2),
        }
        p = Path(LOG_DIR) / "portfolio.jsonl"
        with p.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception as e:
        print(f"log_portfolio error: {e}")


# ── Tinkoff Signals (SignalService) ────────────────────────────
async def fetch_tinkoff_signals(client, instrument_uid: str) -> list:
    """Получить торговые сигналы по инструменту за последние 7 дней."""
    try:
        now = datetime.now(timezone.utc)
        week_ago = now - timedelta(days=7)
        from t_tech.invest.schemas import GetSignalsRequest, SignalState

        request = GetSignalsRequest(
            instrument_uid=instrument_uid,
            from_=week_ago,
            to=datetime.now(timezone.utc),
            active=SignalState.SIGNAL_STATE_ACTIVE,
        )
        resp = await client.signals.get_signals(request=request)
        signals = []
        for s in resp.signals:
            signals.append(
                {
                    "signal_id": s.signal_id,
                    "strategy_id": s.strategy_id,
                    "strategy_name": s.strategy_name,
                    "instrument_uid": s.instrument_uid,
                    "create_dt": s.create_dt.isoformat() if s.create_dt else None,
                    "direction": s.direction.name if s.direction else "UNKNOWN",
                    "initial_price": qfloat(s.initial_price),
                    "target_price": qfloat(s.target_price),
                    "probability": s.probability,
                    "stoploss": qfloat(s.stoploss),
                    "close_price": qfloat(s.close_price),
                    "close_dt": s.close_dt.isoformat() if s.close_dt else None,
                    "info": s.info,
                    "name": s.name,
                }
            )
        return signals
    except Exception as e:
        print(f"[SIGNALS] Fetch error: {e}")
        return []


def compute_indicators(candles: list) -> dict:
    clusters = [
        [qfloat(c.close) for c in candles],
        [qfloat(c.high) for c in candles],
        [qfloat(c.low) for c in candles],
        [c.volume for c in candles],
    ]
    closes, highs, lows, volumes = clusters
    result = {
        "close": closes[-1] if closes else 0,
        "volume": volumes[-1] if volumes else 0,
        "ema_fast": None,
        "ema_slow": None,
        "rsi": None,
        "adx": None,
        "momentum": None,
        "vol_avg": None,
        "bb_lower": None,
        "bb_mid": None,
        "bb_upper": None,
    }
    if len(closes) >= EMA_FAST:
        result["ema_fast"] = calc_ema(closes, EMA_FAST)
    if len(closes) >= EMA_SLOW:
        result["ema_slow"] = calc_ema(closes, EMA_SLOW)
    if len(closes) >= RSI_PERIOD + 1:
        result["rsi"] = calc_rsi(closes, RSI_PERIOD)
    if len(closes) >= 14 * 2 + 1:
        result["adx"] = calc_adx(highs, lows, closes, 14)
        result["plus_di"] = calc_plus_di(highs, lows, closes, 14)
        result["minus_di"] = calc_minus_di(highs, lows, closes, 14)
    if len(closes) >= MOMENTUM_PERIOD + 1:
        result["momentum"] = calc_momentum(closes, MOMENTUM_PERIOD)
    if volumes:
        result["vol_avg"] = calc_volume_avg(volumes, 20)
    bb_l, bb_m, bb_u = calc_bollinger(closes)
    result["bb_lower"] = bb_l
    result["bb_mid"] = bb_m
    result["bb_upper"] = bb_u
    n = min(len(closes), PERCENTILE_DAYS * 525, 500)
    if len(closes) >= 100:
        subset = closes[-n:]
        result["percentile_high"] = calc_percentile(subset, PERCENTILE_FILTER)
        result["percentile_low"] = calc_percentile(subset, 100 - PERCENTILE_FILTER)
    return result


def analyze_signal(indicators: dict) -> str:
    ef = indicators.get("ema_fast")
    es = indicators.get("ema_slow")
    rsi = indicators.get("rsi")
    adx = indicators.get("adx")
    mom = indicators.get("momentum")
    va = indicators.get("vol_avg")
    vol = indicators.get("volume", 0)
    if None in (ef, es, rsi):
        return "NEUTRAL"
    trend_up = ef > es * (1 - EMA_MARGIN_PCT / 100)
    vol_ok = va and va > 0 and vol >= va * VOLUME_MULTIPLIER and vol >= VOLUME_ABS_MIN
    adx_ok = adx is None or adx >= ADX_MIN
    mom_ok = mom is None or abs(mom) >= MOMENTUM_MIN
    ph = indicators.get("percentile_high")
    pl = indicators.get("percentile_low")
    price = indicators.get("close", 0)
    bb_l = indicators.get("bb_lower")
    bb_u = indicators.get("bb_upper")
    if bb_l is not None and bb_u is not None and BB_FILTER:
        if BB_TOLERANCE > 0:
            bb_long_ok = bb_l <= price <= bb_l * (1 + BB_TOLERANCE / 100)
            bb_short_ok = bb_u * (1 - BB_TOLERANCE / 100) <= price <= bb_u
        else:
            bb_long_ok = price <= bb_u
            bb_short_ok = price >= bb_l
    else:
        bb_long_ok = bb_short_ok = True
    signal = "NEUTRAL"
    if (
        trend_up
        and vol_ok
        and adx_ok
        and mom_ok
        and rsi <= RSI_OVERBOUGHT_FILTER
        and rsi >= RSI_OVERSOLD
        and (ph is None or price <= ph)
        and bb_long_ok
    ):
        signal = "LONG"
    elif (
        not trend_up
        and vol_ok
        and adx_ok
        and mom_ok
        and rsi <= RSI_OVERBOUGHT_FILTER
        and rsi >= RSI_OVERSOLD
        and (pl is None or price >= pl)
        and bb_short_ok
    ):
        signal = "SHORT"

    # DI hard_block filter
    if signal != "NEUTRAL" and DI_HARD_BLOCK:
        di_plus = indicators.get("plus_di") or 0.0
        di_minus = indicators.get("minus_di") or 0.0
        di_diff = abs(di_plus - di_minus)
        if di_diff > DI_THRESHOLD and di_plus > 0 and di_minus > 0:
            if di_plus > di_minus and signal == "SHORT":
                signal = "NEUTRAL"
            elif di_minus > di_plus and signal == "LONG":
                signal = "NEUTRAL"

    return signal


def pnl_pct_for(side, entry, cur) -> float:
    if entry <= 0:
        return 0.0
    return ((cur - entry) / entry * 100) if side == "LONG" else ((entry - cur) / entry * 100)


def calc_commission(price, contract_multiplier, lot, comm_pct) -> float:
    return price * contract_multiplier * (comm_pct / 100) * lot


def calc_pnl(side, entry, price, lot, tick_size=1.0, tick_value=1.0) -> float:
    if entry <= 0 or tick_size <= 0:
        return 0.0
    diff = price - entry if side == "LONG" else entry - price
    ticks = diff / tick_size
    return round(ticks * tick_value * lot, 2)


# ── market detection via API ─────────────────────────────────


def detect_market_from_candles(candles) -> bool:
    """Если возраст последней свечи ≤ 10 мин — рынок активен."""
    if not candles:
        return False
    last = candles[-1]
    age = (datetime.now(timezone.utc) - last.time).total_seconds()
    return age <= 600


# ── main ──────────────────────────────────────────────────────


async def main():
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)

    if state.running:
        print("[BOT] Already running.")
        return

    token = os.getenv("TINKOFF_SANDBOX_TOKEN")
    if not token:
        token = os.getenv("TINKOFF_TOKEN")
    if not token:
        print("ERROR: no token in .env")
        return

    print(f"[BOT] Start {TICKER} | SANDBOX={SANDBOX} | SDK gRPC", flush=True)

    state.raw_candles = []
    stats = load_stats_from_logs()
    for k, v in stats.items():
        setattr(state, k, v)
    print(f"[BOT] Logs: {state.trade_count} trades, P/L={state.total_pnl:+.2f}", flush=True)

    state.last_error = None

    async_client = AsyncClient(token, target=SDK_TARGET, app_name=f"{TICKER}Bot")

    async with async_client as client:
        # Resolve instrument
        instr = await client.instruments.future_by(id_type=2, class_code="SPBFUT", id=TICKER)
        figi = instr.instrument.figi
        uid = instr.instrument.uid
        state.tick_size = qfloat(instr.instrument.min_price_increment)
        state.tick_value = qfloat(instr.instrument.min_price_increment_amount)
        state.basic_asset_size = qfloat(instr.instrument.basic_asset_size)
        state.contract_multiplier = (
            state.tick_value / state.tick_size if state.tick_size > 0 else state.basic_asset_size
        )
        print(
            f"[BOT] {TICKER} → FIGI={figi} UID={uid} tick={state.tick_size}/{state.tick_value} asset_size={state.basic_asset_size} mult={state.contract_multiplier:.0f}",
            flush=True,
        )
        state.current_figi = figi

        # Apply ticker-specific param overrides (whitelisted keys only)
        import configbot as _cfg

        _ALLOWED_OVERRIDES = {
            "STOP_LOSS_PCT",
            "TAKE_PROFIT_PCT",
            "TRAILING_ACTIVATE",
            "TRAILING_DISTANCE",
            "ADX_MIN",
            "RSI_OVERBOUGHT_FILTER",
            "VOLUME_MULTIPLIER",
            "VOLUME_ABS_MIN",
            "MOMENTUM_PERIOD",
            "MOMENTUM_MIN",
            "COMMISSION_PCT",
            "MIN_BETWEEN_SL",
            "MIN_COOLDOWN_SEC",
            "MIN_SIGNAL_STREAK",
            "LOT",
            "MAX_SPREAD_PCT",
            "LEVERAGE_FACTOR",
            "DI_HARD_BLOCK",
            "DI_THRESHOLD",
        }
        _overrides = _cfg.TICKER_PARAMS.get(TICKER, {})
        if _overrides:
            for _k, _v in _overrides.items():
                if _k in _ALLOWED_OVERRIDES:
                    globals()[_k] = _v
                else:
                    print(f"[BOT] WARNING: unknown override key '{_k}' — ignored", flush=True)
            print(f"[BOT] Applied {len(_overrides)} overrides for {TICKER}: {_overrides}", flush=True)

        # Account
        aid = ACCOUNT_ID or os.getenv("TINKOFF_SANDBOX_ACCOUNT_ID") or os.getenv("TINKOFF_ACCOUNT_ID") or ""
        if not aid:
            accs = await client.users.get_accounts()
            if accs.accounts:
                aid = accs.accounts[0].id
        if not aid:
            print("ERROR: no account ID")
            return
        client._account_id = aid
        print(f"[BOT] Account: {aid}", flush=True)

        # Log sandbox balance (auto pay-in removed, account set up manually)
        if SANDBOX:
            try:
                pf = await client.operations.get_portfolio(account_id=aid)
                bal = qfloat(pf.total_amount_currencies or pf.total_amount_futures or MoneyValue())
                state.portfolio_balance = bal
                print(f"[BOT] Sandbox balance: {bal:.0f} RUB", flush=True)
            except Exception as e:
                print(f"[BOT] Sandbox portfolio check: {e}", flush=True)

        # Preload candles (try candle log first, then API)
        candles, today_str = [], datetime.now(timezone.utc).strftime("%Y-%m-%d")
        log_candles = load_candles_from_log(today_str)
        if log_candles:
            print(f"[BOT] Candle log: {len(log_candles)} candles, newest={log_candles[-1].time}", flush=True)
            candles = log_candles
            from_utc = log_candles[-1].time
        else:
            now_utc = datetime.now(timezone.utc)
            if PRELOAD_HOURS > 0:
                from_utc = now_utc - timedelta(hours=PRELOAD_HOURS)
                print(f"[BOT] Loading {PRELOAD_HOURS}h history...", flush=True)
            else:
                session_start = await get_session_start(client, TICKER)
                if session_start is None:
                    from_utc = now_utc - timedelta(hours=48)
                    print("[BOT] Session start not found, fallback 48h", flush=True)
                else:
                    from_utc = session_start - timedelta(minutes=1)
                    print(f"[BOT] Loading from session start {session_start} UTC", flush=True)
        async for c in client.get_all_candles(figi=figi, from_=from_utc, to=datetime.now(timezone.utc), interval=1):
            if not candles or (hasattr(c, "time") and c.time > candles[-1].time):
                candles.append(c)
        if not candles and PRELOAD_HOURS == 0:
            print("[BOT] No candles from session start, fallback to 48h", flush=True)
            from_utc = datetime.now(timezone.utc) - timedelta(hours=48)
            async for c in client.get_all_candles(figi=figi, from_=from_utc, to=datetime.now(timezone.utc), interval=1):
                candles.append(c)
        # Ensure enough candles for indicator warmup (EMA_SLOW=21 + buffer)
        MIN_WARMUP_CANDLES = 100
        if len(candles) < MIN_WARMUP_CANDLES:
            print(
                f"[BOT] Only {len(candles)} candles, loading {MIN_WARMUP_CANDLES - len(candles)} more for warmup...",
                flush=True,
            )
            now_utc = datetime.now(timezone.utc)
            from_utc = now_utc - timedelta(hours=48)
            extra_candles = []
            async for c in client.get_all_candles(figi=figi, from_=from_utc, to=datetime.now(timezone.utc), interval=1):
                if not extra_candles or (hasattr(c, "time") and c.time > extra_candles[-1].time):
                    extra_candles.append(c)
            # Merge, avoiding duplicates
            existing_times = {c.time for c in candles}
            for c in extra_candles:
                if c.time not in existing_times:
                    candles.append(c)
            candles.sort(key=lambda x: x.time)

        if not candles:
            print("ERROR: no candle data", flush=True)
            return
        print(f"[BOT] Loaded {len(candles)} candles, last={candles[-1].time}", flush=True)
        state.raw_candles = candles

        # Resume position (sandbox)
        position = Position()
        position.lot = 0
        if SANDBOX:
            try:
                pf = await client.operations.get_portfolio(account_id=aid)
                for p in pf.positions:
                    if p.figi == figi and qfloat(p.quantity) != 0:
                        qty = int(abs(qfloat(p.quantity)))
                        ep = qfloat(p.average_position_price) if p.average_position_price else 0
                        position.side = "LONG" if qfloat(p.quantity) > 0 else "SHORT"
                        position.lot = qty
                        position.entry_price = ep
                        position.peak_price = ep
                        position.entry_time = datetime.now(timezone.utc)
                        # Log RESUME only once per session (skip duplicates from main() restarts)
                        if (
                            getattr(state, "_resume_logged", False)
                            and state.position.side == position.side
                            and state.position.lot == qty
                            and state.position.entry_price == ep
                        ):
                            print("[RESUME] skipped (already logged)", flush=True)
                        else:
                            print(f"[RESUME] {position.side} {qty} @ {ep:.4f}", flush=True)
                            log_trade(f"RESUME {position.side}", figi, TICKER, qty, ep)
                            state._resume_logged = True
                        break
                bal = qfloat(pf.total_amount_currencies or pf.total_amount_futures or MoneyValue())
                state.portfolio_balance = bal
            except Exception as e:
                print(f"[RESUME] portfolio error: {e}", flush=True)
        # Real GO for current position
        try:
            margin = await client.users.get_margin_attributes(account_id=aid)
            state.portfolio_blocked = (
                qfloat(margin.guarantee_for_futures) if qfloat(margin.guarantee_for_futures) > 0 else 0.0
            )
        except Exception:
            pass

        state.position.side = position.side
        state.position.entry_price = position.entry_price
        state.position.lot = position.lot
        state.position.peak_price = position.peak_price
        state.force_close = False

        # Print config
        print(f"\n{'=' * 50}", flush=True)
        print(f"BOT READY | {TICKER} | {'SANDBOX' if SANDBOX else 'PROD'}", flush=True)
        print(f"EMA:{EMA_FAST}/{EMA_SLOW} RSI:{RSI_PERIOD} ADX>={ADX_MIN}", flush=True)
        if position.side != "NONE":
            print(f"Position: {position.side:5} @ {position.entry_price:.4f}", flush=True)
        print(f"{'=' * 50}\n", flush=True)

        # ── Startup briefing ──
        try:
            print("[BOT] Generating startup briefing...", flush=True)
            await _briefing.main()
            print("[BOT] Startup briefing done.", flush=True)
        except Exception as e:
            print(f"[BOT] Briefing start error: {e}", flush=True)

        # ── Initial Tinkoff Signals fetch ──
        try:
            signals = await fetch_tinkoff_signals(client, uid)
            state.signals = signals
            print(f"[SIGNALS] Loaded {len(signals)} signals", flush=True)
        except Exception as e:
            print(f"[SIGNALS] Initial fetch error: {e}", flush=True)
            state.signals = []

        # ── Periodic signals refresh task ──
        async def signals_refresh_task():
            while get_lifecycle_event().is_set():
                await asyncio.sleep(600)  # каждые 10 минут
                if not get_lifecycle_event().is_set():
                    break
                try:
                    signals = await fetch_tinkoff_signals(client, uid)
                    state.signals = signals
                    print(f"[SIGNALS] Refreshed {len(signals)} signals", flush=True)
                except Exception as e:
                    print(f"[SIGNALS] Refresh error: {e}", flush=True)

        signals_task = asyncio.create_task(signals_refresh_task())

        # ── Market data stream setup ──
        candle_queue = asyncio.Queue(maxsize=100)
        stream_open = asyncio.Event()
        stream_error = None
        stream_ref = None

        reconnecting = False
        state.stream_connected = True

        async def stream_worker():
            """Background: consume market data stream via AsyncMarketDataStreamManager → push to queue."""
            nonlocal stream_error, stream_ref
            try:
                manager = AsyncMarketDataStreamManager(market_data_stream=client.market_data_stream)
                stream_ref = manager

                # Subscribe via managed API (instrument_id preferred over figi)
                manager.candles.waiting_close(True).subscribe(
                    [
                        CandleInstrument(
                            instrument_id=uid,
                            interval=SubscriptionInterval.SUBSCRIPTION_INTERVAL_ONE_MINUTE,
                        )
                    ]
                )
                manager.info.subscribe([InfoInstrument(instrument_id=uid)])

                stream_open.set()

                async for md in manager:
                    for f in (
                        "candle",
                        "trading_status",
                        "subscribe_candles_response",
                        "subscribe_info_response",
                        "subscribe_last_price_response",
                        "subscribe_order_book_response",
                        "subscribe_trades_response",
                        "last_price",
                        "orderbook",
                        "trade",
                        "open_interest",
                    ):
                        val = getattr(md, f, None)
                        if val is not None:
                            if f in (
                                "subscribe_candles_response",
                                "subscribe_info_response",
                                "subscribe_last_price_response",
                                "subscribe_order_book_response",
                                "subscribe_trades_response",
                            ):
                                await candle_queue.put(("subscribed", time.time()))
                            elif f == "candle":
                                await candle_queue.put(("candle", val))
                            elif f == "trading_status":
                                await candle_queue.put(("status", val))
                            elif f in ("ping", "last_price", "orderbook", "trade", "open_interest"):
                                await candle_queue.put(("ping", time.time()))
                            break
            except Exception as e:
                stream_error = e
                stream_open.set()

        worker = asyncio.create_task(stream_worker())
        await stream_open.wait()

        if stream_error:
            print(f"[BOT] Stream error: {stream_error}", flush=True)

        # ── Main lifecycle loop ──
        market_open = detect_market_from_candles(candles)
        prev_signal = ""
        signal_streak = 0

        state.start_time = datetime.now()
        force_close_retries = 0
        _reconnect_attempt = 0
        _reconnect_next_log = 0.0
        _reconnect_intervals = [30, 60, 90]

        while True:
            # Если бот остановлен API — выйти из main() для clean restart
            if not get_lifecycle_event().is_set() and state.start_time:
                break
            while not get_lifecycle_event().is_set():
                await asyncio.sleep(0.5)
            state.running = True

            try:
                # ── Wait for event (instant response to stream / buttons) ──
                msg_type = msg = None
                last_heartbeat_ts = time.time()
                while True:
                    if not candle_queue.empty():
                        msg_type, msg = candle_queue.get_nowait()
                        break
                    if state.force_close and market_open and position.side != "NONE":
                        msg_type = msg = None
                        break
                    if state.manual_entry_side:
                        msg_type = msg = None
                        break
                    if worker.done() and not reconnecting:
                        break  # worker died → reconnect
                    if time.time() - last_heartbeat_ts > 60:
                        last_heartbeat_ts = time.time()
                        print("[BOT] Waiting for stream data...", flush=True)
                    await asyncio.sleep(0.5)

                now_utc = datetime.now(timezone.utc)
                now_msk = now_utc + timedelta(hours=3)

                # ── Reconnect on dead worker ──
                if worker.done() and not reconnecting:
                    reconnecting = True
                    _reconnect_attempt += 1
                    now_ts = time.time()
                    if now_ts >= _reconnect_next_log:
                        interval = _reconnect_intervals[min(_reconnect_attempt - 1, len(_reconnect_intervals) - 1)]
                        _reconnect_next_log = now_ts + interval
                        print(f"[BOT] Reconnect #{_reconnect_attempt}, next log in {interval}s", flush=True)
                    state.stream_connected = False
                    if stream_ref:
                        try:
                            stream_ref.stop()
                        except Exception:
                            pass
                    worker.cancel()
                    try:
                        await worker
                    except Exception:
                        pass
                    while not candle_queue.empty():
                        try:
                            candle_queue.get_nowait()
                        except asyncio.QueueEmpty:
                            break
                    # Restart worker — manager handles internal retries with backoff
                    stream_open.clear()
                    stream_error = None
                    stream_ref = None
                    worker = asyncio.create_task(stream_worker())
                    try:
                        await asyncio.wait_for(stream_open.wait(), timeout=30)
                        if stream_error:
                            raise stream_error
                        state.stream_connected = True
                        reconnecting = False
                        _reconnect_attempt = 0
                        _reconnect_next_log = 0.0
                        print("[BOT] Stream reconnected", flush=True)
                    except Exception as e:
                        state.stream_connected = False
                        print(f"[BOT] Worker restart failed: {e}", flush=True)
                        await asyncio.sleep(10)
                    continue

                # ── Process candle from stream ──
                if msg_type == "candle":
                    c = msg
                    if candles and candles[-1].time == c.time:
                        candles[-1] = c
                    else:
                        candles.append(c)
                        log_candle(c)
                    if len(candles) > 500:
                        candles = candles[-500:]
                    state.raw_candles = candles

                # ── Process trading status ──
                if msg_type == "status":
                    ts = msg
                    market_open = (
                        ts.trading_status == SecurityTradingStatus.SECURITY_TRADING_STATUS_NORMAL_TRADING
                        or ts.market_order_available_flag
                        or ts.limit_order_available_flag
                    )

                # ── Compute indicators ──
                price = qfloat(candles[-1].close) if candles else 0
                state.current_price = price
                indicators = compute_indicators(candles)
                state.ind_ema = indicators.get("ema_fast") or 0.0
                state.ind_ema_slow = indicators.get("ema_slow") or 0.0
                state.ind_rsi = indicators.get("rsi") or 0.0
                state.ind_adx = indicators.get("adx") or 0.0
                state.ind_momentum = indicators.get("momentum") or 0.0
                if indicators.get("vol_avg"):
                    state.ind_volume_mult = round(indicators["volume"] / indicators["vol_avg"], 2)
                state.ind_percentile_high = indicators.get("percentile_high") or 0.0
                state.ind_percentile_low = indicators.get("percentile_low") or 0.0
                signal = analyze_signal(indicators)

                if signal == prev_signal and signal != "NEUTRAL":
                    signal_streak += 1
                elif signal != "NEUTRAL":
                    signal_streak = 1
                else:
                    signal_streak = 0

                # ── Briefing trigger: on directional change only (LONG<->SHORT), ignore NEUTRAL flips ──
                if signal != "NEUTRAL" and prev_signal not in ("NEUTRAL", signal) and market_open:
                    print(f"[BOT] Signal change: {prev_signal} -> {signal}, triggering briefing", flush=True)
                    asyncio.create_task(_safe_briefing())

                prev_signal = signal

                if DEBUG and msg_type == "candle":
                    print(
                        f"[{now_msk.strftime('%H:%M')}] "
                        f"p={price:.4f} EMA={indicators['ema_fast'] or 0:.4f}/{indicators['ema_slow'] or 0:.4f} "
                        f"RSI={indicators['rsi'] or 0:.1f} ADX={indicators['adx'] or 0:.1f} "
                        f"MOM={indicators['momentum'] or 0:+.4f}% V={indicators['volume']:>4}/{indicators['vol_avg'] or 0:>4.0f} "
                        f">>> {signal:7} | pos={position.side:5} | streak={signal_streak}/{MIN_SIGNAL_STREAK} | market={'OPEN' if market_open else 'CLOSED'}"
                    )

                if signal != "NEUTRAL" and now_msk.hour >= TIME_FILTER_HOUR:
                    signal = "NEUTRAL"

                if signal != "NEUTRAL" and signal_streak < MIN_SIGNAL_STREAK:
                    signal = "NEUTRAL"

                state.current_signal = signal
                state.signal_streak = signal_streak

                # ── Close logic ──
                if state.force_close and market_open:
                    close_dir = (
                        OrderDirection.ORDER_DIRECTION_SELL
                        if position.side == "LONG"
                        else OrderDirection.ORDER_DIRECTION_BUY
                    )
                    print(
                        f"[FORCE_CLOSE] {position.side} qty={position.lot} dir={'SELL' if close_dir == OrderDirection.ORDER_DIRECTION_SELL else 'BUY'} @ {price:.4f}",
                        flush=True,
                    )
                    try:
                        await close_via_sandbox_or_retry(
                            client,
                            figi=figi,
                            uid=uid,
                            quantity=position.lot,
                            direction=close_dir,
                            account_id=aid,
                            order_type=OrderType.ORDER_TYPE_MARKET,
                            price=price,
                            contract_multiplier=state.contract_multiplier,
                        )
                        com = calc_commission(
                            position.entry_price, state.contract_multiplier, position.lot, COMMISSION_PCT
                        ) + calc_commission(price, state.contract_multiplier, position.lot, COMMISSION_PCT)
                        pnl = (
                            calc_pnl(
                                position.side,
                                position.entry_price,
                                price,
                                position.lot,
                                state.tick_size,
                                state.tick_value,
                            )
                            - com
                        )
                        log_trade("CLOSE (MANUAL)", figi, TICKER, position.lot, price, pnl)
                        print(f"  >> CLOSE (MANUAL) @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                        _circuit_check(pnl, now_utc)
                        state.last_exit_time = now_utc
                        state.force_close = False
                        force_close_retries = 0
                        position.side = "NONE"
                        position.entry_price = 0.0
                        position.peak_price = 0.0
                        position.trailing_active = False
                        position.entry_time = None
                        position.lot = 0
                        state.position.side = "NONE"
                        state._resume_logged = False
                        state.portfolio_blocked = 0.0
                        log_portfolio()
                    except Exception as e:
                        print(f"  >> Force close error: {e}", flush=True)
                        state.record_error(str(e))
                        if "30079" in str(e):
                            state.force_close = False
                            force_close_retries = 0
                        else:
                            force_close_retries += 1
                            if force_close_retries >= 3:
                                state.force_close = False
                                force_close_retries = 0

                elif position.side != "NONE" and market_open:
                    pp = pnl_pct_for(position.side, position.entry_price, price)

                    # Trailing activation
                    if pp >= TRAILING_ACTIVATE and not position.trailing_active:
                        position.trailing_active = True
                        position.peak_price = price
                        state.position.trailing_active = True
                        if DEBUG:
                            print(f"  >> TRAIL ACTIVE @ {price:.4f} (+{pp:.2f}%)", flush=True)

                    # Trailing close
                    if position.trailing_active:
                        is_long = position.side == "LONG"
                        if is_long:
                            if price > position.peak_price:
                                position.peak_price = price
                            trail_level = position.peak_price * (1 - TRAILING_DISTANCE / 100)
                            triggered = price <= trail_level
                            close_dir = OrderDirection.ORDER_DIRECTION_SELL
                        else:
                            if price < position.peak_price:
                                position.peak_price = price
                            trail_level = position.peak_price * (1 + TRAILING_DISTANCE / 100)
                            triggered = price >= trail_level
                            close_dir = OrderDirection.ORDER_DIRECTION_BUY

                        if triggered:
                            try:
                                await close_via_sandbox_or_retry(
                                    client,
                                    figi=figi,
                                    uid=uid,
                                    quantity=position.lot,
                                    direction=close_dir,
                                    account_id=aid,
                                    order_type=OrderType.ORDER_TYPE_MARKET,
                                    price=price,
                                    contract_multiplier=state.contract_multiplier,
                                )
                                com = calc_commission(
                                    position.entry_price, state.contract_multiplier, position.lot, COMMISSION_PCT
                                ) + calc_commission(price, state.contract_multiplier, position.lot, COMMISSION_PCT)
                                pnl = (
                                    calc_pnl(
                                        position.side,
                                        position.entry_price,
                                        price,
                                        position.lot,
                                        state.tick_size,
                                        state.tick_value,
                                    )
                                    - com
                                )
                                log_trade(f"CLOSE (TRAIL @ {trail_level:.4f})", figi, TICKER, position.lot, price, pnl)
                                print(f"  >> TRAIL CLOSE @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                                _circuit_check(pnl, now_utc)
                                state.last_exit_time = now_utc
                                position.reset()
                                state.position.side = position.side
                                state.position.entry_price = position.entry_price
                                state.position.peak_price = position.peak_price
                                state.position.trailing_active = position.trailing_active
                                state.position.lot = position.lot
                                state._resume_logged = False
                                state.portfolio_blocked = 0.0
                                log_portfolio()
                            except Exception as e:
                                print(f"  >> Trailing close error: {e}", flush=True)
                                state.record_error(str(e))

                    # Stop-Loss
                    if position.side != "NONE" and pp <= -STOP_LOSS_PCT:
                        close_dir = (
                            OrderDirection.ORDER_DIRECTION_SELL
                            if position.side == "LONG"
                            else OrderDirection.ORDER_DIRECTION_BUY
                        )
                        notional_est = price * position.lot * state.contract_multiplier
                        print(
                            f"  >> SL attempt: qty={position.lot} @ {price:.4f} (notion~{notional_est:.0f})", flush=True
                        )
                        try:
                            await close_via_sandbox_or_retry(
                                client,
                                figi=figi,
                                uid=uid,
                                quantity=position.lot,
                                direction=close_dir,
                                account_id=aid,
                                order_type=OrderType.ORDER_TYPE_MARKET,
                                price=price,
                                contract_multiplier=state.contract_multiplier,
                            )
                            com = calc_commission(
                                position.entry_price, state.contract_multiplier, position.lot, COMMISSION_PCT
                            ) + calc_commission(price, state.contract_multiplier, position.lot, COMMISSION_PCT)
                            pnl = (
                                calc_pnl(
                                    position.side,
                                    position.entry_price,
                                    price,
                                    position.lot,
                                    state.tick_size,
                                    state.tick_value,
                                )
                                - com
                            )
                            log_trade("CLOSE (SL)", figi, TICKER, position.lot, price, pnl)
                            print(f"  >> SL @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                            _circuit_check(pnl, now_utc)
                            state.last_exit_time = now_utc
                            state.last_sl_time = now_utc
                            position.reset()
                            state.position.side = position.side
                            state.position.entry_price = position.entry_price
                            state.position.peak_price = position.peak_price
                            state.position.trailing_active = position.trailing_active
                            state.position.lot = position.lot
                            state._resume_logged = False
                            state.portfolio_blocked = 0.0
                            log_portfolio()
                        except Exception as e:
                            print(f"  >> SL error: {e}", flush=True)
                            state.record_error(str(e))

                    # Take-Profit
                    if position.side != "NONE" and pp >= TAKE_PROFIT_PCT:
                        close_dir = (
                            OrderDirection.ORDER_DIRECTION_SELL
                            if position.side == "LONG"
                            else OrderDirection.ORDER_DIRECTION_BUY
                        )
                        try:
                            await close_via_sandbox_or_retry(
                                client,
                                figi=figi,
                                uid=uid,
                                quantity=position.lot,
                                direction=close_dir,
                                account_id=aid,
                                order_type=OrderType.ORDER_TYPE_MARKET,
                                price=price,
                                contract_multiplier=state.contract_multiplier,
                            )
                            com = calc_commission(
                                position.entry_price, state.contract_multiplier, position.lot, COMMISSION_PCT
                            ) + calc_commission(price, state.contract_multiplier, position.lot, COMMISSION_PCT)
                            pnl = (
                                calc_pnl(
                                    position.side,
                                    position.entry_price,
                                    price,
                                    position.lot,
                                    state.tick_size,
                                    state.tick_value,
                                )
                                - com
                            )
                            log_trade("CLOSE (TP)", figi, TICKER, position.lot, price, pnl)
                            print(f"  >> TP @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                            _circuit_check(pnl, now_utc)
                            state.last_exit_time = now_utc
                            position.reset()
                            state.position.side = position.side
                            state.position.entry_price = position.entry_price
                            state.position.peak_price = position.peak_price
                            state.position.trailing_active = position.trailing_active
                            state.position.lot = position.lot
                            state._resume_logged = False
                            state.portfolio_blocked = 0.0
                            log_portfolio()
                        except Exception as e:
                            print(f"  >> TP error: {e}", flush=True)
                            state.record_error(str(e))

                    state.position.side = position.side
                    state.position.entry_price = position.entry_price
                    state.position.peak_price = position.peak_price
                    state.position.trailing_active = position.trailing_active
                    state.position.lot = position.lot

                # ── Open logic ──
                manual_side = state.manual_entry_side
                state.manual_entry_side = ""
                if manual_side:
                    # Apply safety filters to manual entry
                    if now_msk.hour >= TIME_FILTER_HOUR:
                        print(f"  >> MANUAL BLOCKED: after {TIME_FILTER_HOUR}:00 MSK", flush=True)
                        manual_side = ""
                    if market_open and candles:
                        last_close = price
                        recent_range = (
                            max(qfloat(c.high) - qfloat(c.low) for c in candles[-5:]) if len(candles) >= 5 else 0
                        )
                        if recent_range and abs(price - last_close) > 10 * recent_range:
                            print(f"  >> MANUAL BLOCKED: price {price:.2f} outside sane range", flush=True)
                            manual_side = ""
                    signal = manual_side

                if position.side == "NONE" and signal != "NEUTRAL" and market_open:
                    # Cooldown checks
                    if state.last_sl_time and (now_utc - state.last_sl_time).total_seconds() < MIN_BETWEEN_SL:
                        signal = "NEUTRAL"
                    if state.last_exit_time and (now_utc - state.last_exit_time).total_seconds() < MIN_COOLDOWN_SEC:
                        signal = "NEUTRAL"
                    # Circuit breaker: N consecutive losses = cooldown
                    if state.circuit_breaker_until:
                        if now_utc < state.circuit_breaker_until:
                            signal = "NEUTRAL"
                        else:
                            state.circuit_breaker_until = None
                            state.circuit_breaker = False
                    # Check margin sufficiency before entry
                    margin_ok = True
                    try:
                        await margin_lim.acquire()
                        margin = await client.users.get_margin_attributes(account_id=aid)
                        if qfloat(margin.funds_sufficiency_level) <= 1.0:
                            print("  >> Insufficient margin, skip entry", flush=True)
                            margin_ok = False
                    except Exception as e:
                        print(f"  >> Margin check warning: {e}", flush=True)
                    if margin_ok:
                        if MAX_SPREAD_PCT > 0 and state.contract_multiplier > 0:
                            try:
                                ob = await client.market_data.get_order_book(figi=figi, depth=1)
                                if ob.bids and ob.asks:
                                    spread_pct = (qfloat(ob.asks[0].price) - qfloat(ob.bids[0].price)) / price * 100
                                    if spread_pct > MAX_SPREAD_PCT:
                                        print(
                                            f"  >> Spread {spread_pct:.3f}% > {MAX_SPREAD_PCT}%, skip entry", flush=True
                                        )
                                        signal = "NEUTRAL"
                            except Exception as e:
                                print(f"  >> Orderbook check warning: {e}", flush=True)
                        try:
                            if LOT > 0:
                                order_lot = LOT
                            elif state.contract_multiplier > 0:
                                order_lot = max(
                                    1, int(INITIAL_EQUITY * LEVERAGE_FACTOR / (price * state.contract_multiplier))
                                )
                            else:
                                order_lot = 10
                            direction = (
                                OrderDirection.ORDER_DIRECTION_BUY
                                if signal == "LONG"
                                else OrderDirection.ORDER_DIRECTION_SELL
                            )
                            await post_order_with_retry(
                                client,
                                figi=figi,
                                uid=uid,
                                quantity=order_lot,
                                direction=direction,
                                account_id=aid,
                                order_type=OrderType.ORDER_TYPE_MARKET,
                            )
                            position.side = signal
                            position.entry_price = price
                            position.entry_bar = len(candles)
                            position.lot = order_lot
                            position.entry_time = now_utc
                            position.peak_price = price
                            position.trailing_active = False
                            log_trade(
                                f"{'[MANUAL] ' if manual_side else ''}OPEN {signal} {order_lot}л",
                                figi,
                                TICKER,
                                order_lot,
                                price,
                            )
                            state.position.side = signal
                            state.position.entry_price = price
                            state.position.entry_bar = len(candles)
                            state.position.entry_time = now_utc
                            state.position.peak_price = price
                            state.position.lot = order_lot
                            try:
                                await margin_lim.acquire()
                                margin = await client.users.get_margin_attributes(account_id=aid)
                                state.portfolio_blocked = (
                                    qfloat(margin.guarantee_for_futures)
                                    if qfloat(margin.guarantee_for_futures) > 0
                                    else round(price * order_lot * state.contract_multiplier, 2)
                                )
                            except Exception:
                                state.portfolio_blocked = (
                                    round(price * order_lot * state.contract_multiplier, 2) if SANDBOX else 0.0
                                )
                            log_portfolio()
                            print(f"  >> OPEN {signal} @ {price:.4f}", flush=True)
                        except Exception as e:
                            print(f"  >> Open error: {e}", flush=True)
                            state.record_error(str(e))

                # Clear stale errors
                if state.last_error and "Cannot connect" in str(state.last_error):
                    state.last_error = None

            except asyncio.CancelledError:
                print("\nBot cancelled.", flush=True)
                break
            except Exception as e:
                import traceback

                print(f"[BOT] Error: {e}", flush=True)
                traceback.print_exc()
                state.record_error(str(e))
                if isinstance(e, RuntimeError):
                    raise  # stream dead too long → full restart via run_forever
                await asyncio.sleep(5)

        signals_task.cancel()
        try:
            await signals_task
        except asyncio.CancelledError:
            pass
        worker.cancel()
        if stream_ref:
            try:
                stream_ref.stop()
            except Exception:
                pass
        print("[BOT] Stopped.", flush=True)


async def run_forever(ticker=None):
    """Запускает main() в бесконечном цикле с авто-перезапуском при сбоях."""
    from shared import init_console_logging

    init_console_logging()
    if ticker:
        import configbot

        configbot.TICKER = ticker
        os.environ["BOT_TICKER"] = ticker
    get_lifecycle_event().set()
    state._resume_logged = False
    import traceback

    delay = 1
    while True:
        try:
            await main()
            delay = 1
        except asyncio.CancelledError:
            break
        except Exception as e:
            print(f"[BOT] CRASH: {e}", flush=True)
            traceback.print_exc()
            print(f"[BOT] Restart in {delay}s...", flush=True)
            await asyncio.sleep(delay)
            delay = min(delay * 2, 60)
            continue
        # main() вернулась (stop) — ждём /api/bot/start
        while not get_lifecycle_event().is_set():
            await asyncio.sleep(0.5)


if __name__ == "__main__":
    import argparse

    _parser = argparse.ArgumentParser()
    _parser.add_argument("--ticker", default=None, help="Instrument ticker")
    _args = _parser.parse_args()
    asyncio.run(run_forever(ticker=_args.ticker))
